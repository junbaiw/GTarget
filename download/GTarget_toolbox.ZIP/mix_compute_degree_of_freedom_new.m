function dim=mix_compute_degree_of_freedom_new(all_dimMF,len_dimMF,record_all_dimMF_sign,record_all_dimMF_coef,full_discrete,full_discrete_sublevel,full_continues)
%start to compute the degree of freedom based on submodels
%the formula of degree of freedom is from Lozense's book 'Graphical models'
%at chapter of 'mixed models' 
%[all_dimMF{1:end}]
%record_all_dimMF_sign %0 is +, 1 is -
%pause
%full_discrete={'AB'};
%full_discrete_sublevel=[2,3];
%full_continues={'XY'};

dim=0;
for i=1:len_dimMF
    temp_submodel=all_dimMF{i};
    %check the generate(d,c)(d,0),or (d,ab)
    str_continues=intersect(strvcat(temp_submodel),strvcat(full_continues));
    str_discrete=intersect(strvcat(temp_submodel),strvcat(full_discrete));
    if (isempty(str_continues) & isempty(str_discrete))
        %dim(0) empty
        %disp('model1')
        if record_all_dimMF_sign(i)==0
            dim=dim+1*record_all_dimMF_coef(i);
        elseif record_all_dimMF_sign(i)==1
            dim=dim-1* record_all_dimMF_coef(i);
        end
    elseif (isempty(str_continues) & ~isempty(str_discrete))
        %dim(d,0) discrete model
        %disp('model2')
        sub_dim=1;
        for j=1:length(str_discrete);
            idx_of_str=findstr(strvcat(str_discrete(j)),strvcat(full_discrete));
            if ~isempty(idx_of_str)
                sub_dim=sub_dim*full_discrete_sublevel(idx_of_str);
            end
        end
        if record_all_dimMF_sign(i)==0
            dim=dim+sub_dim* record_all_dimMF_coef(i);
        elseif record_all_dimMF_sign(i)==1
            dim=dim-sub_dim* record_all_dimMF_coef(i);
        end
    else   
        %bug at here!!!
        %find number of continues string
	total_num_of_cont_str=0;
        for kk=1:length(str_continues)
		temp_str_continues=strvcat(str_continues(kk));
		total_num_of_cont_str= total_num_of_cont_str+length(findstr(temp_str_continues,strvcat(temp_submodel)));
	end	
	if (length(str_continues)<2 & total_num_of_cont_str==1)
            %dim(d,r) linear model
            %disp('model3')
            sub_dim=1;
            for j=1:length(str_discrete);
                idx_of_str=findstr(strvcat(str_discrete(j)),strvcat(full_discrete));
                if ~isempty(idx_of_str)
                    sub_dim=sub_dim*full_discrete_sublevel(idx_of_str);
                end
            end
            if record_all_dimMF_sign(i)==0
                dim=dim+2*sub_dim* record_all_dimMF_coef(i);
            elseif record_all_dimMF_sign(i)==1
                dim=dim-2*sub_dim* record_all_dimMF_coef(i);
            end
        end
        
        if (length(str_continues)<2 & total_num_of_cont_str>1)
            %dim(d,r^2) quadet model
            %disp('model4')
            sub_dim=1;
            for j=1:length(str_discrete);
                idx_of_str=findstr(strvcat(str_discrete(j)),strvcat(full_discrete));
                if ~isempty(idx_of_str)
                    sub_dim=sub_dim*full_discrete_sublevel(idx_of_str);
                end
            end
            if record_all_dimMF_sign(i)==0
                dim=dim+3*sub_dim* record_all_dimMF_coef(i);
            elseif record_all_dimMF_sign(i)==1
                dim=dim-3*sub_dim* record_all_dimMF_coef(i);
            end
        end
        
        if (length(str_continues)>1 & total_num_of_cont_str==2)
            %dim(d,{r,u}) quadet model , this has to be checked later!!
            %disp('model5')
            sub_dim=1;
            for j=1:length(str_discrete);
                idx_of_str=findstr(strvcat(str_discrete(j)),strvcat(full_discrete));
                if ~isempty(idx_of_str)
                    sub_dim=sub_dim*full_discrete_sublevel(idx_of_str);
                end
            end
            if record_all_dimMF_sign(i)==0
                dim=dim+4*sub_dim* record_all_dimMF_coef(i);
            elseif record_all_dimMF_sign(i)==1
                dim=dim-4*sub_dim* record_all_dimMF_coef(i);
            end
        end
        
        if (length(str_continues)>1 & total_num_of_cont_str>2)
            %dim(d,c^2) quadet model , this has to be checked later!!
            %disp('model6')
            sub_dim=1;
            for j=1:length(str_discrete);
                idx_of_str=findstr(strvcat(str_discrete(j)),strvcat(full_discrete));
                if ~isempty(idx_of_str)
                    sub_dim=sub_dim*full_discrete_sublevel(idx_of_str);
                end
            end
            
            len_of_str_continues=length(strvcat(str_continues));
            
	    if record_all_dimMF_sign(i)==0
                dim=dim+sub_dim*(len_of_str_continues+1)*(len_of_str_continues+2)/2* record_all_dimMF_coef(i);
            elseif record_all_dimMF_sign(i)==1
                dim=dim-sub_dim*(len_of_str_continues+1)*(len_of_str_continues+2)/2* record_all_dimMF_coef(i);
            end
        end 
    end
end %end for
%dim	
