function [out_data,LL,Deviance]=mix_modifiedIPS_homogeneous(all_data,all_moments,out_data, cell_location, ia, ...
    out_cellIndex,convergens,isdebuge)
%format long e
%Input: out_data is initial values for all parameters
%ia is the number of submodel, out_cellIndex contains the index of each
%submodel
%this function compute homogeneous mixed model and loops only once!!
global old_out_data new_out_data
istype=out_cellIndex.istype;
remove_edges=out_cellIndex.remove_edges;
cell_idx=out_cellIndex.cell_idx;
sub_model_level=out_cellIndex.sub_model_level;
sub_discrete_models=size(out_cellIndex.cell_idx{1},1);
%added wang aug 2005
nij=all_moments.nij;
uij=all_moments.uij;
sigmaij=all_moments.sigmaij;
obs_pij=all_moments.obs_pij;
obs_uij=all_moments.obs_uij;
obs_sigmaij=all_moments.obs_sigmaij;
%added wang
%find empty cell in nij
%good_idx=find(obs_pij>0);
%end added

N=all_moments.N;
q=all_moments.q;

continues_data=all_data.continues_data;
discrete_data=all_data.discrete_data;
Ls=all_data.Ls;

new_out_data={};
num_dist=1;
new_out_data=cell(size(out_data)); 
max_parm_diff=1000;
cycle=1;
oldest_out_data=out_data;
%conVar=mix_compute_sigma(continues_data);
old_LL=-100000000000000;
max_no_iteration=500;
is_true=zeros(1,ia);
is_true_can=zeros(1,ia);

obs_moment.record_obs_sigma=cell(ia,max(sub_model_level));
obs_moment.record_obs_n=cell(ia,max(sub_model_level));
obs_moment.record_obs_u=cell(ia,max(sub_model_level));

while 1
   level_count=1;
   for i=1:ia
        %loop in submodels
       	if isdebuge==1 
            cycle
        end
        %clear obs_moment fitted_moment
        fitted_moment=[];

        %compute moment variable based on updated out_data!       
        [obs_moment, fitted_moment]=mix_homoSigma(all_data,all_moments,out_data, ...
            cell_location, ia, out_cellIndex,i,cycle,obs_moment);

    	%loop in ia: marginal count to descrite variable ia
        temp_cell={};
        fitted_pij=[];
        fitted_uij={};
        fitted_sigmaij={};
        delta_alpha={};
        delta_beta={};
        delta_omega={};
        temp_cell_idx=[];
        current_alpha={};
        current_beta={};
        current_omega={};
        max_parm_diff=[];
        new_out_data={};
        temp_parm_diff=zeros(size(sub_model_level));
        %new_out_data=cell(size(out_data));        
        for j=1:sub_model_level(i)
            %add wang
            %loop in sublevel of each ia
            %clear obs_alpha obs_beta obs_omega fitted_alpha fitted_beta fitted_omega delta_alpha delta_beta delta_omega
            obs_alpha=[];
            obs_beta=[];
            obs_omega=[];
            fitted_alpha=[];
            fitted_beta=[];
            fitted_omega=[];
            temp_cell=[];
            current_ia=i;
            current_ia_level=j;
            temp_cell=cell_idx{i};
            if iscell(temp_cell)
		        temp_cell_idx{j}=temp_cell{current_ia_level};
            else
                temp_cell_idx{j}=temp_cell(current_ia_level);
            end
            %add wang oct 2005 find empty cell
          
              
            %clear current_alpha current_beta current_omega
            current_alpha{j}={out_data{temp_cell_idx{j},1}};
            current_beta{j}={out_data{temp_cell_idx{j},2}};
            current_omega{j}={out_data{temp_cell_idx{j},3}};
            [row,col]=size(current_alpha{j});
            
            
            %clear obs_n obs_u obs_sigma
            obs_n=[];
            obs_u=[];
            obs_sigma=[];
            obs_n=obs_moment.record_obs_n{i,j};
            obs_u=obs_moment.record_obs_u{i,j};
            obs_sigma=obs_moment.record_obs_sigma{i,j};
		
            fitted_n=fitted_moment.record_fitted_n{i,j};
            fitted_u=fitted_moment.record_fitted_u{i,j};
            fitted_sigma=fitted_moment.record_fitted_sigma{i,j};
 	   
            
            delta_m_ia=abs(obs_n-fitted_n);
            delta_u_ia=max(max(abs(obs_u-fitted_u)));
            delta_sigma_ia=max(max(abs(obs_sigma-fitted_sigma)));
            max_parm_diff(j)=max([delta_m_ia/sqrt(fitted_n+1),delta_u_ia,delta_sigma_ia]);
                    
            %added wang
            obs_sigma(find(obs_sigma>=0.9999 & obs_sigma<=1.0))=1;
            fitted_sigma(find(fitted_sigma>=0.9999 & fitted_sigma<=1.0))=1;
            %Sep 2005!! end added wang
                              
            %  obs_p,obs_u,i,j,obs_sigma
            [obs_alpha, obs_beta, obs_omega]=mix_moment2canonical_new2(obs_n,obs_u,obs_sigma,q,N);
                    
            [fitted_alpha,fitted_beta,fitted_omega]=mix_moment2canonical_new2(fitted_n,fitted_u,fitted_sigma,q,N);
            gema_n=1;
                 
            %compute canconical paremeter difference
            delta_alpha{j}=(obs_alpha-fitted_alpha);
            delta_beta{j}=(obs_beta-fitted_beta);
            delta_omega{j}=(obs_omega-fitted_omega);
					
            [new_out_data,fitted_pij,fitted_uij,fitted_sigmaij,delta_alpha,delta_beta,delta_omega,...
                 gema_n,temp_parm_diff]=mix_MIPS_update(...
                        fitted_pij,fitted_uij,fitted_sigmaij,...
                        N,q,gema_n,new_out_data,current_alpha,current_beta,current_omega,...
                        delta_alpha,delta_beta,delta_omega,temp_cell_idx,j,temp_parm_diff,out_data,all_moments);
        end %end j
          
        %maximum canonical difference between updated parameters
        temp_max_parm_diff=max(temp_parm_diff);
        
       if (max(max_parm_diff)>convergens ) 
            %normzlize fitted n, sometimes it makes algorithm hard to
            %converge!
            [new_out_data,fitted_pij]=mix_normalizeFittedN(new_out_data,N,q,fitted_pij);
            %end normalize
           
           %fitted model likelihood
            Lm=mix_likelihood_fittedModel_new(N,obs_pij,obs_uij,obs_sigmaij,q,...
                fitted_pij,fitted_uij,fitted_sigmaij);
            
            if isdebuge==1 
         		LL=Lm*(-2);
                vpa(LL)
         		Deviance=abs(-2*(Ls-Lm))
                old_LL=Lm;
                %pause
            else
                LL=Lm*(-2);
                Deviance=abs(-2*(Ls-Lm));
                old_LL=Lm;
            end
            old_out_data=out_data;
            %disp('Updata data')
            %vpa(new_out_data{1,6},6)
            
        	if isdebuge==1
                out_data=new_out_data;
            else
                out_data=new_out_data;
            end
       end %end if update
       
       if  max(max_parm_diff)<convergens
            is_true(i)=1;
       end 	
        
        
       %maximum moment difference between updated parameters 
       if isdebuge==1
            vpa(max(max_parm_diff),9)
            max_canonical_parm_diff=vpa(temp_max_parm_diff,9)
            [is_true; is_true_can]
            pause
       end
         
       if  temp_max_parm_diff<convergens
                is_true_can(i)=1;
                %below assuem if moment variable less than convergens then
                %the canonical variable is less too! This is cheat
                is_true_can(find(is_true==1))=1; 
       end 	    
       cycle=cycle+1;
       % pause
    end %end i 
  
	if cycle>max_no_iteration
		disp('Max no iteration reached!');
		break;
	end

	if (sum(sum(is_true))/ia==1 | sum(sum(is_true_can))/ia==1)
        is_true;
        	is_true_can;
		break;
	end
end %end while

