function [alpha, beta, omega]=mix_moment2canonical_new2(n,u,sigma,q,N)
%Input moment parameter p, u, sigma, q is the number of continous variables
%disp('imc')
%format long e
%n,u,sigma
%digits(64);
omega=pinv(sigma);
omega(find(omega>=0.9999 & omega<=1.0))=1;         
beta=omega*u;

%added wang
det_sigma=det(sigma);
if det_sigma<=0 %2.9E-38 %3.7201e-044 %2.9E-38
    alpha=0;
    beta=zeros(size(beta));
    omega=zeros(size(omega));
else
    if n>2.9E-38 %3.7201e-044
        log_n=log(n);
    else
        log_n=-88.02886; %-100;
    end
    alpha=log_n-1/2.*log(det_sigma)-1/2.*u'*omega*u-q/2.*log(2*pi)-log(N);
   %	alpha=log(p)-1/2.*log(det_sigma)-1/2.*u'*omega*u-q/2.*log(2*pi);
end
%alpha,beta,omega
