function stringVector=mix_make_discreteString(numberVector)
%input number of edge location
%output corresponding the string name for example
%current only have 10 discrete variables
%Input [ 1 2; 2 3]
%Output {A B; B C}
[r c]=size(numberVector);
if max([r c])<27
   for i=1:r
      tempNum=numberVector(i,:);
      tempString=[];
      for j=1:length(tempNum)
        tempString=strcat(tempString,char(64+tempNum(j)));
       end
       stringVector{i}=tempString;
    end
else
  display('Maxim discrete variable is 26 ! He Stop!')
  return;
end
