function plotdata = plotdata(Y,cmap,cmin,cmax,figno,titstr,clean,xticks,yticks,datasize,gensym)

if(clean~=0)
   figure(figno);
   clf;
end

pcolor([1:size(Y,2)+1]-0.5,[1:size(Y,1)+1]-0.5, ...
       [Y,zeros(size(Y,1),1);zeros(1,size(Y,2)),0]);
shading flat;
%title(titstr);
colormap(cmap);
caxis([cmin,cmax]);
%title(titstr);
set(gcf,'NextPlot','Add');
%H=gca;
%set(H,'YTick',[1:datasize(1)+1]);
%set(H,'YTickLabelMode','Manual');
%set(H,'YTickLabel',char(yticks));
%set(H,'XTick',[1:datasize(2)]);
%set(H,'XTickLabelMode','Manual');
%set(H,'XTickLabel',char(xticks));
%ylabel('Gene');
%xlabel('Sample');


ax1=gca;
set(ax1,'YAxisLocation','right');
set(ax1,'YTick',[1:datasize(1)+1]);
set(ax1,'YTickLabelMode','Manual');
set(ax1,'YTickLabel',char(gensym));
set(ax1,'fontsize',2);

%colorbar('horiz')
%colorbar('NorthOutside');
xlimits=get(ax1,'XLim');
step1=xlimits(1)+0.6:xlimits(2);

set(ax1,'XAxisLocation','bottom');
set(ax1,'XTick',step1);
set(ax1,'XTickLabelMode','Manual');
set(ax1,'XTickLabel',char(xticks));
xt=get(gca,'Xtick')   ;
xticklabel_rotate(reshape(xt,1,max(size(xt))),90,reshape(cellstr([char(deblank(xticks))]),1,max(size(xticks)))   );  
set(ax1,'fontsize',2);

%Bellow is option for the multi Axes
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top','YAxisLocation','left',...
           'Color','none',...
           'XColor','k','YColor','k');%shading faceted;
ylimits = get(ax2,'yLim');
%set(ax2,'PlotBoxAspectRatio',[0.5 1 1]) 
set(ax2,'fontsize',2);
%here need manual adjust!!!
step=(ylimits(2)-ylimits(1))/datasize(1);
%here need manual adjust!!!
%step2=[ylimits(1)+0.0845:step:ylimits(2)];
step2=[ylimits(1)+step/2:step:ylimits(2)];

lnstep=length(step2);
step3=step2(1:lnstep);
set(ax2,'XTickLabel','');
set(ax2,'YTick',step3)
set(ax2,'YTickLabelMode','Manual');
set(ax2,'YTickLabel',char(yticks));

