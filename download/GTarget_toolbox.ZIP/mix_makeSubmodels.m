function new_model=mix_makeSubmodels(full_model,delete_edgeStr,full_discrete,full_continues)
%make a submodel based on deleted edges
%
%delete edge in discrete model
temp_d_model=full_model.d_model;
len_d_model=length(temp_d_model);
idx=1;
for i=1:len_d_model
	for j=1:length(delete_edgeStr)
		temp_d=[]; temp_di=[];
		[temp_d temp_di]=setdiff(temp_d_model{i},delete_edgeStr(j));
		if ~isempty(intersect(strvcat(temp_d_model{i}(sort(temp_di))),strvcat(full_discrete)))
			d_model{idx}=temp_d_model{i}(sort(temp_di));
			idx=idx+1;
		end
	end
end
d_out_model=mix_remove_overlapModel(d_model);
 
%delete edge in linear model
temp_l_model=full_model.l_model;
len_l_model=length(temp_l_model);
idx=1;
for i=1:len_l_model
	for j=1:length(delete_edgeStr)
		[temp_l temp_li]=setdiff(temp_l_model{i},delete_edgeStr(j));
		if ~isempty(intersect(strvcat(temp_l_model{i}(sort(temp_li))),strvcat(full_continues)))
			l_model{idx}=temp_l_model{i}(sort(temp_li));
			idx=idx+1;
		end
	end
end
l_out_model=mix_remove_overlapModel(l_model);
l_out_model=mix_delete_singleDiscrete(l_out_model);

%delete edge in quardic model
temp_q_model=full_model.q_model;
len_q_model=length(temp_q_model);
len_q_model=length(temp_q_model);
idx=1;
for i=1:len_q_model
	for j=1:length(delete_edgeStr)
		[temp_q temp_qi]=setdiff(temp_q_model{i},delete_edgeStr(j));
                q_model{idx}=temp_q_model{i}(sort(temp_qi));
                idx=idx+1;
        end
end
q_out_model=mix_remove_overlapModel(q_model);
q_out_model=mix_delete_singleDiscrete(q_out_model);
new_model.d_model=d_out_model;
new_model.l_model=l_out_model;
new_model.q_model=q_out_model;



