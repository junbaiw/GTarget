%diary
%model exp=1,tf=2 is the best !
%var need change 1.22. 6
close all
clear all

%use one cycle the results more stable!
%diary
%1) read data
isfile=5
exp_ismodel=4 %2
%1 is regress, 2 is gnet

tf_ismodel=3 %3
%1 is gnet, 2 is ggm, 3 is mixM, 4 is pc alg
is_impute=0;
is_ngas=1;
%model 2 is the best
global graph_form
%ismodel 1 is gaussian network, 2 is ggm, 3 is mixG, 4 is pc algorithm, 
%GGM has the best resutls

%read data
if isfile==1
    file1='cellCycle_data/cycle_SpellmanAlphaExp_plus_SimenChip.txt'
    %file1='cellCycle_data/cycle_SpellmanAlphaExp_plus_SimenChip_200genes.txt'
    %file1='cellCycle_data/cell_cycle_spellman_alphaData_ExpChipData.txt'
    %two cell cycle
elseif isfile==2
    file1='cellCycle_data/cycle_SpellmanCdc15Exp_plus_SimenChip.txt'
    %three cell cycle
elseif isfile==3
    file1='cellCycle_data/cycle_SpellmanCdc28Exp_plus_SimenChip.txt'
    %two cell cycle
elseif isfile==4
    file1='cellCycle_data/cycle_SpellmanEluExp_plus_SimenChip.txt'
    %one cell cycle
elseif isfile==5
     file1='cellCycle_data/cycle_exp_plus_chip.txt';
    %all cell cycle data together 54 genes
    file2='cellCycle_data/cell_cycle_spellmanExp_and_simonChip_data.txt';
elseif isfile==6
    file1='cellCycle_data/cell_cycle_spellmanExp_and_simonChip_data_old.txt';
    %all exp and genes of spellman data 722 genes and 69 exps
elseif isfile==7
     file1='science_data/gaussInput_filamentous_pathway_MissImput_plus_chipData.dat';
elseif isfile==8
     file1='science_data/gaussInput_hog_pathway_MissImput_plus_chipData.dat';
elseif isfile==9
	file1='cellCycle_data/cycle_exp_plus_seqMatch_1missmatch.txt'
     file2='cellCycle_data/cell_cycle_spellmanExp_and_simonChip_data.txt'
elseif isfile==10
     file1='cellCycle_data/cycle_exp_plus_chip.csv';
end

[tdata, tvars,tcases]=tblread(file1,'\t');
if isfile==6 | isfile==7 |isfile==8
    tdata(:,end-8:end)=log2(tdata(:,end-8:end));
    tdata=som_normalize(tdata,'var');
elseif isfile==5
     [tdata2, tvars2,tcases2]=tblread(file2,'\t'); %read dataset with 800 genes
     tdata2(:,end-8:end)=log2(tdata2(:,end-8:end));
     tdata2=som_normalize(tdata2,'var');
     %find 54 genes
     [tcases,ia,ib]=intersect(cellstr(lower(tcases)),cellstr(lower(tcases2)));
     tcases=strvcat(tcases);
     tdata=tdata2(ib,:);
elseif isfile==9 %sequence data
     %tdata(:,end-7:end)=tdata(:,end-7:end)+1; %plus 1 extra avoid zero count
     %tdata(:,end-7:end)=log2(tdata(:,end-7:end)); %data from seqMat file
     
     [tdata2, tvars2,tcases2]=tblread(file2,'\t'); %read dataset with 800 genes
     tdata2(:,end-8:end)=log2(tdata2(:,end-8:end));
     tdata2=som_normalize(tdata2,'var');
     %find 54 genes
     [tcases,ia,ib]=intersect(cellstr(lower(tcases)),cellstr(lower(tcases2)));
     tcases=strvcat(tcases);
     tdata(1:length(ib),1:end-8)=tdata2(ib,1:end-9);	
else
      tdata=som_normalize(tdata,'var');
end


%imputation of raw data
if isfile==9
    num_of_tf=8;
else
    num_of_tf=9;
end
if is_impute==1
    if isfile==1
        tsorted_x=[0 7 14 21 28 35 42 49 56 63 70 77 84 91 98 105 112 119]; %alpha
        intervalue=1.75*2; %3.5;
         data_idx=[1:18]; %only use the first cycle [1:18];
         sorted_x=tsorted_x(data_idx);
    elseif isfile==2
        tsorted_x=[10 30 50 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 ...
        220	230	240	250	270	290]; %CDC15
    intervalue=5*2;
     data_idx=[1:24]; %only use the first cycle [1:24];
      sorted_x=tsorted_x(data_idx);
    elseif isfile==3
        tsorted_x=[0 10 20 30 40 50 60 70 80 90 100 110 120	130	140	150	160]; %CDC28
        intervalue=2.5*2;
         data_idx=[1:17]; %only use the first cycle [1:17];
          sorted_x=tsorted_x(data_idx);
    elseif isfile==4
        tsorted_x=[0 30 60 90 120 150 180 210 240 270 300 330 360 390 ]; %ELU
        intervalue=7.5*2;
        data_idx=[1:14];
        sorted_x=tsorted_x(data_idx);
    elseif isfile==5 |isfile==10
	tn=2;
        tsorted_x1=[0 7 14 21 28 35 42 49 56 63 70 77 84 91 98 105 112 119]; %alpha
        intervalue1=1.75*tn; %3.5;
        data_idx1=[1:18]; %only use the first cycle [1:18];
        sorted_x1=tsorted_x1(data_idx1);
        %alpha
        
        tsorted_x2=[10 30 50 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 ...
        220	230	240	250	270	290]; %CDC15
        intervalue2=5*tn;
        data_idx2=[1:24]; %only use the first cycle [1:24];
        sorted_x2=tsorted_x2(data_idx2);
        %CDC15
        
         tsorted_x3=[0 10 20 30 40 50 60 70 80 90 100 110 120	130	140	150	160]; %CDC28
         intervalue3=2.5*tn;
         data_idx3=[1:17]; %only use the first cycle [1:17];
         sorted_x3=tsorted_x3(data_idx3);
        %CDC28
        
        tsorted_x4=[0 30 60 90 120 150 180 210 240 270 300 330 360 390 ]; %ELU
        intervalue4=7.5*tn;
        data_idx4=[1:14];
        sorted_x4=tsorted_x4(data_idx4);
        %ELU
    end
    
    
    if isfile<5
        [vars,new_x,new_y]=data_interpration(tdata, data_idx,intervalue,sorted_x,tvars,num_of_tf,isfile);
    else
        vars=[];
        new_x=[];
        new_y=[];
        kt_data_idx=0;
       for k=1:4
           t_data_idx=kt_data_idx+eval(['data_idx',num2str(k)]);
           t_data_idx,
            tvars(t_data_idx,:)
           eval(['sorted_x',num2str(k)])
           %pause
           [ttvars,ttnew_x,ttnew_y]=data_interpration(tdata, [t_data_idx ],...
               eval(['intervalue',num2str(k)]),eval(['sorted_x',num2str(k)]),tvars,num_of_tf,isfile);
           vars=[vars,ttvars];
           kt_data_idx=length(t_data_idx)+kt_data_idx;
           
           new_x=[new_x,ttnew_x];
           new_y=[new_y,ttnew_y];
       end
       for k=1:num_of_tf
           vars{k+length(new_x(1,:))}=tvars(end-num_of_tf+k,:);
       end
    end
else
    new_y=tdata(:,1:end-num_of_tf);
    new_x=1:(size(tvars,1)-num_of_tf); %[0 7 14 21 28 35 42 49 56 63 70 77 84 91 98 105 112 119];
    vars=tvars;
end
cases=tcases;
tvars=strvcat(vars);
vars=strvcat(vars);
%added wang
data=[new_y]; %,tdata(:,end-num_of_tf+1:end)];
norm_data=data; %som_normalize(data,'var');
all_norm_data=[data,tdata(:,end-num_of_tf+1:end)];
disp(['Finish data interpration data size :', num2str(size(norm_data))] )
%pause


x=norm_data;
[n,dim]=size(x);
delta_dis=[]; 
%2) use nGas to find the best dimension of genes
if is_ngas==1
if isfile==6
    max_clusters=ceil(n/15); % 5 or 20
else %if isfile==5
    max_clusters=ceil(n/4);
end

for ik=1:10
for i=2:n
    if ( i> max_clusters)
        break
    end
    c=i;
    y0=(rand(c,dim)-0.5)*10e-5;
    beta=1.5;
    epochs=500;
    [fuzzy_center1, fuzzy_member1]=fuzzy_nGas(x,y0,c,beta,epochs);
 
    fuzzy_centerOld.data=x;
    fuzzy_centerOld.codebook=x;
    old_msize=n;
    fuzzy_center.data=x;
    fuzzy_center.codebook=fuzzy_center1;
    msize=c;
    itc=i;
    [dissimilar_density, minCluster_distance,chtest,df]=stress_forCluster_centers(...
       fuzzy_centerOld,fuzzy_center,itc,msize,old_msize);
    dis(i)=dissimilar_density
    p(i)=chtest;
    degF(i)=df;
    delta_dis(i)=abs(dis(i)-dis(i-1));
    record_center{i}=fuzzy_center1;
    record_member{i}=fuzzy_member1;
end
  [min_dis,min_idx]=min(dis(2:end));                                                                          
  tcenters=size(record_center{min_idx+1});  
  loop(ik,:)=tcenters
  loop_centers{ik}=record_center{min_idx+1};
end %end ik

centers=ceil(median(loop(:,1)));
centers(2)=loop(1,2)
lidx=find(loop(:,1)==centers(1));
if ~isempty(lidx)
	new_centers=loop_centers{lidx(1)};
	disp('use predefined centers');
else
	new_centers=(rand(centers)-0.5)*10e-5;
	disp('use random centers')
end
disp('Finish nGas ...')

%fine turning of the center
 beta=1.5;
 epochs=500;
 x=norm_data;
 y0=new_centers; %    record_center{min_idx+1};
 c=size(y0,1);
 [fuzzy_center1, fuzzy_member1]=fuzzy_nGas(x,y0,c,beta,epochs);
 disp('Fine turning of center')
 prototype=fuzzy_center1;
Cp=[1:centers(1)]';
%3) use knn to find  the best clusters for each center from nGas
d=sqrt(som_eucdist2(x,prototype));
d(eye(size(d))==1)==NaN;
K=1;
beta=1.5;
[c P]=fuzzy_knnnew(d,Cp,K,beta);

%4) plot 1-nearst neighbour genes related with prototype genes
nlevels =10;
redgreen = makecolormap(nlevels);
cmin = -2; % measured in standard deviations if scale=1
cmax =  2; % measured in standard deviations if scale=1
figno=1;
titstr=['Fuzzy ',num2str(K),'-nearest neighbor']
tempx=cellstr(tvars); %{'E12.5','E14.5','E16.5','E18.5','P0.5','P2.5','P4.5','P6.5','adult_reitna'};
figno=3;
casenames=tcases;
record_y=[];
[str_r,str_c]=size(casenames);
%names={'c1','c2','c3','c4','c5','c6','c7'}
prototype_name={};
prototype_cases={};
is_data=1;
for i=1:centers(1) % 15 prototype
    %figure(figno)
    %clf
    names=['noVar1_C_',num2str(i)];
    [n_r,n_c]=size(names);
    names=[names,repmat(' ',1,str_c-n_c)];
    %casenames(i,:)
    temp=P(:,i);
    idx=find(temp>0);
    tempP=temp(idx,:);
    tempy=casenames(idx,:)
    if ~isempty(tempy)
        prototype_cases{is_data}=tempy;
        prototype_name{is_data}=names;
        tempdata=x(idx,:);
        datasize=size([prototype(i,:);tempdata]);
        if i==20
            idx
        end
        subplot(2,1,2)
        plot(1:centers(2),tempdata','b-');
        hold on;
        plot(1:centers(2),prototype(i,:),'r-.','LineWidth',2);
        hold on;
        plot(centers(2)+1:centers(2)+num_of_tf,tdata(idx,end-num_of_tf+1:end),'k-');
        hold on;
        plot(centers(2)+1:centers(2)+num_of_tf,mean(tdata(idx,end-num_of_tf+1:end),1),'r-');
        axis([0 length(new_x(1,:))+num_of_tf min(prototype(i,:)) max(prototype(i,:)) ]);
        %colorbar('horiz')
        xlabel('Time point and chip data');
        ylabel('Expression data');
        title(titstr);
        hold off
        subplot(2,1,1)
        chip_data=[mean(tdata(idx,end-num_of_tf+1:end),1);tdata(idx,end-num_of_tf+1:end)];
        plot_data1=[prototype(i,:);tempdata];
        plot_data2=[plot_data1,chip_data];
      
        plotdata(plot_data2,redgreen,cmin,cmax,figno,titstr,0,tempx,strvcat([cellstr(names);cellstr(tempy(:,:))]),datasize,num2str([1;tempP]));
        hold on;
          if tf_ismodel==3
             names=['mix2_',names];
           end
	    print('-dpsc','-r200',deblank(names));
        record_cluster_label{is_data}=names;
        record_cluster_data(is_data,:)=prototype(i,:);
        is_data=is_data+1;
        %pause
    end
   record_y=[record_y;tempy];
end
%n,size(record_y),size(unique(record_y,'rows'))
disp('Finish kNN....')
else
    %centers=size(tdata);
    prototype=norm_data;
    record_cluster_data=norm_data;
end %end is_ngas

%pause

idx_of_exp={[1:length(new_x(1,:))]}
record_pdag=[];
ln_of_data=size(all_norm_data,2);
%new_data=norm_data(:,[idx_of_exp{1},ln_of_data-num_of_tf+1:ln_of_data]); %prototype; %cluster centers
new_names=vars([idx_of_exp{1},ln_of_data-num_of_tf+1:ln_of_data],:); %prototype_name; %cluster name
new_cases=cases; %prototype_cases; %genes at each cluster
if exp_ismodel==1
    %use REGRESS to find out TF experimental activation profiles    
    M=tdata(:,end-num_of_tf+1:end); %all_norm_data(:,[ln_of_data-num_of_tf+1:ln_of_data]);
    E=norm_data(:,[idx_of_exp{1}]);
    [u,s,v]=svd(M);
    old_A=v*inv(s'*s)*s'*u'*E;
    %compute  Z-Score for global mean and std
    %mean_hits=mean(reshape(A,1,size(A,1)*size(A,2)));
    %std_hits=std(reshape(A,1,size(A,1)*size(A,2)));
    %Z_hits=(A-mean_hits)./std_hits;
    
    %Z-Score for local exp mean and std
    %each Tfs has mean 0 and var 1 Best
    %Z_hits=som_normalize(old_A','var');
    %Z_hits=Z_hits';
    
    %Z-Score for local exp mean and std
    %each Condition/Exp has mean 0 and var 1
    %Z_hits=som_normalize(old_A,'var');
    
    %no normalization
    Z_hits=old_A;
    
    A=Z_hits;
    figure(4)
    hist(A)
    %pause
elseif exp_ismodel==2
    %use GNET
    %Gaussian networks
    %marray_debuge('Run BScore search algorizm with random restart')
    %old_var=cov(norm_data);  
    N=size(all_norm_data,1); % number of observations
    q=size(all_norm_data,2); % number of variables
    %cutoff=0.05;
    graph_form=2;
    tG=setdiag(triu(randn(q,q)>1),0).*(-1);
    isordered=0;
    [old_parcorrf,pdag_wang ,GG, maxScore]=MGraph_BGscore_hillClimb2_rs(all_norm_data,tG,0.30);
    maxScore
    record_pdag=[pdag_wang(1:end-num_of_tf,end-num_of_tf+1:end)+1];
elseif exp_ismodel==3
  %transfer Experimental activation proiles to Z score and comput its p
    M=tdata(:,end-num_of_tf+1:end); %all_norm_data(:,[ln_of_data-num_of_tf+1:ln_of_data]);
    E=norm_data(:,[idx_of_exp{1}]);
    [u,s,v]=svd(M);
    A=v*inv(s'*s)*s'*u'*E;
    
    %compute P value for Z-Score for global mean and std
    %mean_hits=mean(reshape(A,1,size(A,1)*size(A,2)));
    %std_hits=std(reshape(A,1,size(A,1)*size(A,2)));
    %Z_hits=(A-mean_hits)./std_hits;
    
    
    %Z-Score for local exp mean and std
    %each tf has mean 0 and var 1
    Z_hits=som_normalize(A','var');
    Z_hits=Z_hits';
    
    %figure(14)
    %hist(Z_hits)
    %syms x
    %clear P
    %phi=1/sqrt(2*pi)*exp(-(x^2)/2)
    %for ki=1:num_of_tf
    %    for kj=1:size(Z_hits,2)
    %        tP=int(phi,x,Z_hits(ki,kj),inf);
    %        P(ki,kj)=eval(tP);
    %        %if P(ki,kj)>0.5
    %        %    tP=int(phi,x,-inf,Z_hits(ki,kj));
    %        %    P(ki,kj)=eval(tP);
    %        %end
    %    end
    %end
    record_pdag=zeros(size(Z_hits));
    record_pdag(find(Z_hits>=1))=1;
    %record_pdag(find(Z_hits<1 & Z_hits>=0))=2;
    %record_pdag(find(Z_hits<0 & Z_hits>-1))=3;
    record_pdag(find(Z_hits<=-1))=2;
    %record_pdag(find(P<0.32))=1;
    %record_pdag(find(P>0.68))=2;
    figure(12)
    hist(Z_hits);
    hold on
    plot([0+1*1,0+1*1],[0 10],'r-');
    hold on
      plot([0-1*1,0-1*1],[0 10],'r-');
     if tf_ismodel==3
         print('-dpsc','-r200','mix2_zhits');
     else
          print('-dpsc','-r200','zhits2');
      end
      %pause
elseif exp_ismodel==4
   %read pre-defined tf_exp activation data
   file_tf='cellCycle_data/new_tf_expdata_noOverlap.txt'
   [tf_data,tf_vars,tf_cases]=tblread(file_tf,'\t');
   record_pdag=tf_data;
end

%6) make input data for mixed graphical models%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%num_of_tf=9;
mix_data_exp=record_cluster_data'; %prototype'; %(:,1:end-num_of_tf); %new_data(:,1:end-num_of_tf);
if exp_ismodel==2
    mix_data_chip=record_pdag+1; %pdag_wang(1:end-num_of_tf,end-num_of_tf+1:end)+2;
    mix_data=[mix_data_exp,mix_data_chip];
elseif exp_ismodel==3
     mix_data_chip=record_pdag+1; %pdag_wang(1:end-num_of_tf,end-num_of_tf+1:end)+2;
    mix_data=[mix_data_exp,mix_data_chip'];
elseif exp_ismodel==4
    mix_data_chip=record_pdag+1; %pdag_wang(1:end-num_of_tf,end-num_of_tf+1:end)+2;
    mix_data=[mix_data_exp,mix_data_chip];
elseif exp_ismodel==1
    mix_data_chip=A;
    mix_data=[mix_data_exp,mix_data_chip'];
    %normalize each condition/exp/time point has zero mean and variance 1
   % mix_data=som_normalize(mix_data','var')    
    %mix_data=mix_data';
end
mix_vars=vars(1:end-num_of_tf,:);
if is_ngas==1
    mix_names=record_cluster_label; %prototype_name; %new_names;
    tf_idx=1:num_of_tf;
    tf_loop=1;
    for i=length(mix_names)+1:length(mix_names)+num_of_tf
        mix_names{i}=vars(end-num_of_tf+tf_idx(tf_loop),:);
        tf_loop=tf_loop+1;
    end
else
    mix_names=strvcat([cellstr(tcases);cellstr(tvars(end-num_of_tf+1:end,:))]);
end
if is_ngas==1
    mix_cases=record_cluster_label; %prototype_cases; %new_cases;
else
    mix_cases=mix_names;
end


if tf_ismodel==3        
    save clustering_cellcycle54gene_001mixMImput_ExpectedCond
else
    if isfile==9
        save clustering_cellcycle54gene_005ggmNoImput_seqMat_allowOverLap_NoVar1
    end
end

%start to find TF and gene interactions
if tf_ismodel==1
    %use gnet to find TF and gene ineractions
    [r q]=size(mix_data);
    tG=setdiag(triu(randn(q,q)>1),0).*(-1);
    isordered=0;
    old_var=cov(mix_data);  
    q=length(mix_names); % number of observations
    N=size(mix_data,2); % number of variables
    cutoff=0.01; %0.01 is work, 0.05 does not work
    deviceChoice=1;
    graph_form=2;
    [old_parcorrf,pdag_wang ,GG, maxScore]=MGraph_BGscore_hillClimb2_rs(mix_data,tG,0.30);
    spareM=pdag_wang;
    %spareM=(abs(old_parcorrf)>0.0000000001 & abs(old_parcorrf)~=1);
elseif tf_ismodel==2
    %GGM has the best results!
    %t_mix_data=(som_normalize(mix_data,'var'));
    old_var=cov(mix_data);  
    N=size(mix_data,1); % number of observations
    q=size(mix_data,2); % number of variables
    cutoff=0.05/q; %0.01 is work, 0.05 does not work
    graph_form=2;
    [old_parcorrf,delet_edge,record_edge]=MGraph_GaussModel_forward(old_var,N,q,cutoff);
    spareM=(abs(old_parcorrf)>0.0000000001 & abs(old_parcorrf)~=1);
    %save cluster_800genes_GGM_results_9TF_02p
elseif tf_ismodel==4
      %PC algorithm
     old_var=cov(mix_data);  
     N=size(mix_data,1); % number of observations
     q=size(mix_data,2); % number of variables
     cutoff=0.1;
     pdag_wang = wang_learn_struct_pdag_pc('cond_indep_fisher_z', q,q , old_var, N, cutoff);
     spareM=pdag_wang;
elseif tf_ismodel==3
        %select subset of TFs for learning in mixed graphical models
        isfind=1;
    for ki=1:num_of_tf
        for  kj=ki+1:num_of_tf
            %maker pair-wise comparation
            subset_idx=[ki ,kj ]; %2 3 4 ]; %5 6 7 8 9]; [2,3,4,5,6]; %[3,7,8,9]; %[1,2,3,4]
            tfs=mix_names([centers(1)+subset_idx])
            subset_names=mix_names([1:centers(1),centers(1)+subset_idx]);
            subset_data=mix_data(:,[1:centers(1),centers(1)+subset_idx]);
            subset_vars=mix_vars;
 
            ttdata=subset_data;
            ttcname=strvcat(subset_vars);
            ttvname=strvcat(subset_names);
            num_discrete=length(subset_idx);
            num_continues=centers(1);
            discrete_col=(1:length(subset_idx))+centers(1);
            continues_col=1:centers(1);
            full_discrete=mix_make_discreteString(1:num_discrete);
            full_discrete_sublevel=repmat(2,1,num_discrete) ; %[2,2,2,2]; %need improve
            full_continues=mix_make_continueString(1:num_continues);
            P_cutoff=0.05/(centers(1)+2)
            convergens=0.001
            disp('Start mix graph..')
            results_g=mixHomCoheren_search(ttdata,ttcname,ttvname,num_discrete,num_continues,discrete_col,continues_col,...
                full_discrete,full_discrete_sublevel,full_continues,convergens,P_cutoff)
            disp('Finish mix graphical model..')
	
            %start to store data for each test
            stats_tf.g{ki,kj}=results_g;
            stats_tf.tfs{ki,kj}=tfs;
            stats_tf.mix_cases{ki,kj}=mix_cases;	
            
            %start to make export data for cytoscape
            %find d model
            len_of_d=length(results_g.model.d_model);
            for kk=1:len_of_d
                %here only assume pairwise interactions
                [cd,ia,ib]=intersect(strvcat(results_g.model.d_model{kk}),'AB');
                if length(ib)==2
                    record_mix_interactions{isfind}=[deblank(strvcat(tfs(ib(1)))),' pp ',deblank(strvcat(tfs(ib(2))))];
                    isfind=isfind+1;
                %else
                %    error('mix errors!');
                %    break;
                end
            end %end d model
            %find l model
            len_of_l=length(results_g.model.l_model);
            for kk=1:len_of_l
                %find discreate the match
                %here only assume pairwise interaction
                [cd,ia,ib]=intersect(strvcat(results_g.model.l_model{kk}),'AB');
                if ~isempty(cd)
                    for kkk=1:length(ib)
                        %find continues matches
                        [ccd,ica,icb]=intersect(strvcat(results_g.model.l_model{kk}),strvcat(full_continues));
                        if ~isempty(ccd)
                           record_mix_interactions{isfind}=[deblank(strvcat(tfs(ib(kkk)))),' pp ',strvcat(mix_names{icb})];
                           isfind=isfind+1;
                        end
                    end
                end 
            end %end l model
            
        end 
    end
end
disp('Start to draw figure..')
%pause

if tf_ismodel==1|tf_ismodel==2 | tf_ismodel==4
    %draw graph
    plot_fig=14; 
    %figure(plot_fig);
    %clf(plot_fig);
    labels=strrep(cellstr( deblank(mix_names) ),'"','');
   % draw_graph(abs(spareM),lower(labels));
    disp('Finish Gnet ...')
    if isfile==5
         filename='cellcycle54gene_005ggmNoImput_logChipRatio_NoVar1.sif';
    elseif isfile==6
        filename='cellcycle800gene_005ggmNoImput_logChipRatio_var1OnlyinTFs.sif';
    elseif isfile==7
        filename='filmpathway_005ggmNoImput_logChipRatio_var1OnlyinTFs.sif';
    elseif isfile==8
        filename='hogpathway_005ggmNoImput_logChipRatio_var1OnlyinTFs.sif';
    elseif isfile==9
          filename='cellcycle54gene_005ggmNoImput_seqMatch_allowOverLap_Novar1.sif';
    elseif isfile==10
         filename='cellcycle54gene_005ggmNoImput_logChipRatio_var1OnlyinTFs_2.sif';
    end
    isclose=1;
    fid=[];
    [g_r,g_c]=find(triu(spareM));
    vars=strvcat(mix_names);
    cases=strvcat(mix_names);
    fid=export2cytoscape_graph(filename,g_r,g_c,vars,cases,isclose,fid);
end
%save cluster_54genes_mixM_4classResults_all9TF_005Imput_OnlyUnitTFs
if isfile==5
    if tf_ismodel==3
        save cellcycle54gene_001mixMImput_ExpectedCond
    else
        save cellcycle54gene_005ggmNoImput_logChipRatio_NoVar1
    end
elseif isfile==6
    save cellcycle800gene_005ggmNoImput_logChipRatio_var1OnlyinTFs
elseif isfile==7
    save filmpathway_005ggmNoImput_logChipRatio_var1OnlyinTFs
elseif isfile==8
    save  hogpathway_005ggmNoImput_logChipRatio_var1OnlyinTFs
elseif isfile==9
    if tf_ismodel==3
        save cellcycle54gene_005mixNoImput_seqMatch_var1OnlyinTFs
    else
	 save cellcycle54gene_005ggmNoImput_seqMatch_allowOverLap_Novar1
    end
elseif isfile==10
     save cellcycle54gene_005ggmNoImput_logChipRatio_var1OnlyinTFs_2
end

%diary
