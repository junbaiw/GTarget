function stringModel=mix_make_fullModel(num_d,num_c,ishom)
%make a full mix model for number of discrete variable=num_d, 
%number of continues variable=num_c
%ishom=1 is homoneguose model, ishom=0 is hertengenous model
dString=mix_make_discreteString(1:num_d);
cString=mix_make_continueString(1:num_c);

%make discrete  model
d_model=dString;

%make linear model
for i=1:num_c
	l_model{i}=[d_model{1},cString{1}(i)];
end

%make quadratic model
if ishom==1
    q_model={[cString{1}]};
else
    q_model={[dString{1},cString{1}]};
end
stringModel.d_model=d_model;
stringModel.l_model=l_model;
stringModel.q_model=q_model;
%out put is in cell;
