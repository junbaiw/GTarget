function  [all_dimMF, all_dimMF_sign,all_dimMF_coef,dimMF_length]=mix_remove_identical_cell(...
           temp_new_all_dimMF, temp_new_all_dimMF_sign,temp_new_all_dimMF_coef,temp_record_dimMF_length)
%remove all identical cells and update its sign, coef, length
len_of_dimMF=length(temp_new_all_dimMF);
i=1;
while i<=len_of_dimMF
%for i=1:len_of_dimMF
	idx_id=1;
	idx_nonid=1;
	idx_identical=[];
	idx_nonidentical=[];
	for j=i+1:len_of_dimMF
		temp_dm1= temp_new_all_dimMF{i};
		temp_dm2= temp_new_all_dimMF{j};
		is_identical=strcmp( strvcat(sort(temp_dm1)), strvcat(sort(temp_dm2)) );
		if is_identical==1
			%record index for identical cell
			if idx_id==1
				idx_identical(idx_id)=i;
				idx_id=idx_id+1;
				idx_identical(idx_id)=j;
				idx_id=idx_id+1;
			else
				idx_identical(idx_id)=j;
				idx_id=idx_id+1;
			end
		else
			%record index for non-indetical cell
			 idx_nonidentical(idx_nonid)=j;
			 idx_nonid=idx_nonid+1;
		end
	end  %end j
	
	%based on above search start to update
	%always keep visted cell on the top!
	new_idx=1;
	new_all_dimMF={};
	new_all_dimMF_sign=[];
	new_all_dimMF_coef=[];
	record_dimMF_length=[];
	is_visited=[];
	if ~isempty(idx_identical)
		%firt check the sign and coef of identical cells
		temp_sign=temp_new_all_dimMF_sign(idx_identical);
                temp_coef=temp_new_all_dimMF_coef(idx_identical);
                one_idx=find(temp_sign==1);
                zero_idx=find(temp_sign==0);
		if ~isempty(one_idx) & ~isempty(zero_idx)
                    delta_coef=(sum(temp_coef(one_idx))-sum(temp_coef(zero_idx)));
                    if delta_coef>0
                       new_all_dimMF(new_idx)={temp_new_all_dimMF{idx_identical(1)}};
			is_visited(new_idx)=1;
                       new_all_dimMF_coef(new_idx)=abs(delta_coef); 
                       record_dimMF_length(new_idx)=temp_record_dimMF_length(idx_identical(1));
                       new_all_dimMF_sign(new_idx)=1;
                       new_idx=new_idx+1;
                    elseif delta_coef<0
                       new_all_dimMF(new_idx)={temp_new_all_dimMF{idx_identical(1)}};
			is_visited(new_idx)=1;
                       new_all_dimMF_coef(new_idx)=abs(delta_coef); 
                       record_dimMF_length(new_idx)=temp_record_dimMF_length(idx_identical(1));
                       new_all_dimMF_sign(new_idx)=0;
                       new_idx=new_idx+1;
                     end
                 elseif ~isempty(one_idx) & isempty(zero_idx)
                       delta_coef=sum(temp_coef(one_idx));
                       new_all_dimMF(new_idx)={temp_new_all_dimMF{idx_identical(1)}};
			is_visited(new_idx)=1;
                       new_all_dimMF_coef(new_idx)=abs(delta_coef); 
                       record_dimMF_length(new_idx)=temp_record_dimMF_length(idx_identical(1));
                       new_all_dimMF_sign(new_idx)=1;
                       new_idx=new_idx+1;
                 elseif isempty(one_idx) & ~isempty(zero_idx)
                       delta_coef=sum(temp_coef(zero_idx));
                       new_all_dimMF(new_idx)={temp_new_all_dimMF{idx_identical(1)}};
			is_visited(new_idx)=1;
                       new_all_dimMF_coef(new_idx)=abs(delta_coef); 
                       record_dimMF_length(new_idx)=temp_record_dimMF_length(idx_identical(1));
                       new_all_dimMF_sign(new_idx)=0;
                       new_idx=new_idx+1;
                 end %end if
		%new_all_dimMF
		%new_all_dimMF_coef
		%record_dimMF_length
		%new_all_dimMF_sign	
		
		%then  add the rest of non-identical cell
		len_nonid=length( idx_nonidentical);
		new_all_dimMF(new_idx:new_idx+len_nonid-1)={temp_new_all_dimMF{idx_nonidentical}};
		new_all_dimMF_coef(new_idx:new_idx+len_nonid-1)=temp_new_all_dimMF_coef(idx_nonidentical);
		record_dimMF_length(new_idx:new_idx+len_nonid-1)=temp_record_dimMF_length(idx_nonidentical);
		new_all_dimMF_sign(new_idx:new_idx+len_nonid-1)	=temp_new_all_dimMF_sign(idx_nonidentical);

		%plus the sets that had visited in early search
		ed_visited=length( new_all_dimMF_sign);
		if i-1>0
			vect_visited=i-1;
			len_visited=length(1:vect_visited);
			new_all_dimMF(ed_visited+1:ed_visited+len_visited)={temp_new_all_dimMF{1:vect_visited}};
                	new_all_dimMF_coef(ed_visited+1:ed_visited+len_visited)=temp_new_all_dimMF_coef(1:vect_visited);
                	record_dimMF_length(ed_visited+1:ed_visited+len_visited)=temp_record_dimMF_length(1:vect_visited);
                	new_all_dimMF_sign(ed_visited+1:ed_visited+len_visited) =temp_new_all_dimMF_sign(1:vect_visited);
		end
		%pause
	else
		new_all_dimMF=temp_new_all_dimMF;
		is_visited(i)=i;
                new_all_dimMF_coef=temp_new_all_dimMF_coef;
                record_dimMF_length=temp_record_dimMF_length;
                new_all_dimMF_sign =temp_new_all_dimMF_sign;
	end %end if idx_identical

	len_of_dimMF=length(new_all_dimMF);
	i=i+1;
	%temp_is_visited=zeros(1,len_of_dimMF);
	%[i],
	temp_is_visited( is_visited(find(is_visited~=0)))=1;
	%pause
	temp_new_all_dimMF= new_all_dimMF;
	%temp_new_all_dimMF{1:end} 
	%	pause
	temp_new_all_dimMF_sign= new_all_dimMF_sign;
	temp_new_all_dimMF_coef= new_all_dimMF_coef;
	temp_record_dimMF_length=  record_dimMF_length;
end %end i



%update all results
all_dimMF= temp_new_all_dimMF;
%all_dimMF{1:end} 
all_dimMF_sign=temp_new_all_dimMF_sign;
all_dimMF_coef=temp_new_all_dimMF_coef;
dimMF_length=temp_record_dimMF_length;
%pause


