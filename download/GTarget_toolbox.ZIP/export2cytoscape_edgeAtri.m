function export2cytoscape_edgeApri(filename,g_r,g_c,vars,cases)
%fid=fopen(filename,'W');


fprintf(fid,'%s\n','InteractionStrength');
for i=1:length(g_r)
        col_name=deblank(cases(g_r(i),:));
        row_name=deblank(vars(g_c(i),:));
        fprintf(fid,'%s%s%s%s%s%s%s\n',strvcat(row_name),' ','(pp)',' ', ...
                strvcat(col_name),' = ',num2str(data(g_r(i),g_c(i))));
end


