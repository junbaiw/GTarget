function out_model=mix_remove_overlapModel(t_model)
%remove model which is a submodel of others
%Inout new_model is cell
temp_full_model=t_model;

isfinished=0;
is_moved=0;
while isfinished==0
    is_found=0;
    len_of_model=length(temp_full_model);
    initial_model=temp_full_model{1};
    for i=2:len_of_model
        if sum(ismember(initial_model,temp_full_model{i}))==length(initial_model)
           is_found=1; 
        end
    end
    %[is_found,is_moved]
    if is_found==1 & is_moved<length(t_model)
    %remove initial_model from full model
        new_temp_full_model=[];
        new_temp_full_model=temp_full_model(2:end);
        temp_full_model=[];
        temp_full_model=new_temp_full_model;
    elseif is_found==0 & is_moved<length(t_model)
        %move initial model to the end of all models and start again
        new_temp_full_model=cell(size(temp_full_model));
        new_idx=[2:length(temp_full_model),1];
        new_temp_full_model(1:end)=temp_full_model(new_idx);
        temp_full_model=[];
        temp_full_model=new_temp_full_model;
        is_moved=is_moved+1;
    else
        %search finished
        isfinished=1;
        out_model=temp_full_model;
    end
end
