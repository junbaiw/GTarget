function levels=mix_findDiscreteLevels(rats_data,AB_col)
%Input: rats_data is raw data, AB_col is column number of discrete variables
%Output: levels is level of each discrete variable.
%find the number of level in each discrete variable
num_of_discrete=length(AB_col);
for i=1:num_of_discrete
    temp=unique(rats_data(:,AB_col(i)));
    levels(i)=length(temp);
end

