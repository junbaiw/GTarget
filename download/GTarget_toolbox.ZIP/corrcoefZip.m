function z=corrcoefZip(q,i,j,b)
%http://faculty.vassar.edu/lowry/tcall.js
zz=1;
z=zz;
k=i;

while k<=j
	zz=zz*q*k/(k-b);
	z=z+zz;
	k=k+2;
end

