function mix_printView(model, LL, Deviance, Dim, P ,P_cutoff,dStr)
%print results on screen
fieldname=fieldnames(model);
string_out=['[',strvcat(dStr),']:'];
for i=1:length(fieldname)
	temp_field=fieldname{i};
	%eval(['len_temp_field=length(model.', temp_field ,');']);
	%eval(['temp_field_string=model.'temp_field';']);
	var1=getfield(model,temp_field);
	temp_field_string=sort(var1);
	len_temp_field=length(var1);

	for j=1:len_temp_field
		string_out=[string_out,',',strvcat(temp_field_string{j})];
	end
	string_out=[string_out,' / '];
end
string_out=[string_out,' LL=',num2str(LL)];
string_out=[string_out,' ,Deviance=',num2str(Deviance)];
string_out=[string_out,' ,DF=',num2str(Dim)];
string_out=[string_out,' ,P=',num2str(P)]; 
if P<P_cutoff
	string_out=[string_out,' +'];
end
disp(string_out);

