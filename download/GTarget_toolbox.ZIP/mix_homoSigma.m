function [obs_moment, fitted_moment]=mix_homoSigma(all_data,all_moments,out_data, ...
    cell_location, ia, out_cellIndex,index,cycle,obs_moment)
%compute the covariance matrix for homogeneous models of both observed and fitted
%since sigma is same for all cell j then we only need compute once base on all available sigma{j}
sub_model_level=out_cellIndex.sub_model_level;

record_obs_sigma=cell(1,ia);
fitted_moment.record_fitted_sigma=cell(ia,max(sub_model_level)); 
fitted_moment.record_fitted_u=cell(ia,max(sub_model_level));
fitted_moment.record_fitted_n=cell(ia,max(sub_model_level));
record_fitted_sigma=cell(1,ia);  

ishom=1;
istype=out_cellIndex.istype;
remove_edges=out_cellIndex.remove_edges;
cell_idx=out_cellIndex.cell_idx;

%added wang
nij=all_moments.nij;
uij=all_moments.uij;
sigmaij=all_moments.sigmaij;
obs_pij=all_moments.obs_pij;
obs_uij=all_moments.obs_uij;
obs_sigmaij=all_moments.obs_sigmaij;

N=all_moments.N;
q=all_moments.q;

continues_data=all_data.continues_data;
discrete_data=all_data.discrete_data;
Ls=all_data.Ls;

%new_out_data={};
num_dist=1;
new_out_data=cell(size(out_data)); 
max_parm_diff=100;


level_count=1;
%for i=1:ia
i=index;
	obs_temp_sigma=0;
	fitted_temp_sigma=0;

        %loop in submodels
    	%loop in ia: marginal count to descrite variable ia
        for j=1:sub_model_level(i)
        %loop in sublevel of each ia
        clear obs_alpha obs_beta obs_omega fitted_alpha fitted_beta
        clear fitted_omega delta_alpha delta_beta delta_omega
        clear temp_cell temp_cell_idx
            current_ia=i;
            current_ia_level=j;
            temp_cell=cell_idx{i};
            if iscell(temp_cell)
                temp_cell_idx=temp_cell{current_ia_level};
            else
                temp_cell_idx=temp_cell(current_ia_level);
            end
                      
            clear current_alpha current_beta current_omega
            current_alpha={out_data{temp_cell_idx,1}};
            current_beta={out_data{temp_cell_idx,2}};
            current_omega={out_data{temp_cell_idx,3}};
            [row,col]=size(current_alpha);
        
            % do not update empty celles
                if cycle<=ia	    
                %compute observered parameters
                    clear p_ia u_ia sigma_ia
                    %p_ia=nij(temp_cell_idx)./N;
                    n_ia=nij(temp_cell_idx);
                    u_ia=uij(temp_cell_idx,:);
                    sigma_ia=cell(col,1);
                    sigma_ia(1:col)={sigmaij{temp_cell_idx}};
             
                    %added wang aug 05
                    if (istype(i)==2 | istype(i)==3)
                        %both continues and discrete model are partial
                        %not correct
                        t_remove_variable=remove_edges{i};
                        u_ia(:,[t_remove_variable])=0;
                
                        len_of_sigma=length(sigma_ia);
                        for jj=1:len_of_sigma
                    		t_sigma_ia=sigma_ia{jj}; %at here we assume only one sigma in cell!!
                    		for gii=1:length(t_remove_variable)
                        		t_idx=1:size(t_sigma_ia,1);
                        		t_idx=setdiff(t_idx,t_remove_variable(gii));
                        		t_sigma_ia(t_remove_variable(gii),[t_idx])=0;
                        		t_sigma_ia([t_idx],t_remove_variable(gii))=0;
                        		t_sigma_ia(t_remove_variable(gii),t_remove_variable(gii))=1; %mix_compute_sigma(continues_data(:,t_remove_variable(gii))); %1;
                    		end
                    		sigma_ia{jj}=t_sigma_ia;
                        end %end jj
                    end
                    %end added 05 wang
                
                    [obs_n,obs_u,obs_sigma]=mix_observed_HOMmoment_new(...
                            n_ia,u_ia,sigma_ia,q,N,ishom);
                        obs_moment.record_obs_sigma{i,j}=obs_sigma;
                        obs_moment.record_obs_n{i,j}=obs_n;
                        obs_moment.record_obs_u{i,j}=obs_u;
                        obs_temp_sigma=obs_temp_sigma+obs_n.*obs_sigma./N;
                end %end if cycle<=ia
            %end %end if obs is member
            
             %added wang
             if (istype(i)==2 | istype(i)==3)
                    %both continues and discrete model are partial
                    t_remove_variable=remove_edges{i};
                   %replace removed continues with global mean/ 1 in sigma
                   for gii=1:length(t_remove_variable)
                      obs_temp_sigma(t_remove_variable(gii),t_remove_variable(gii))=1;   
                   end
             end
             %end added
            
           
                %compute fitted parameters by current marginal counts in out_data
                clear current_m_ia current_u_ia current_sigma_ia temp_u_ia temp_sigma_ia 
                current_m_ia=[out_data{temp_cell_idx,4}];
                current_u_ia={out_data{temp_cell_idx,5}};
                current_sigma_ia={out_data{temp_cell_idx,6}};
            
                temp_u_ia=current_u_ia;
                temp_sigma_ia=current_sigma_ia;
                %added wang 05 
                if (istype(i)==2 | istype(i)==3)
                    %both continues and discrete model are partial
                    %not correct
                    t_remove_variable=remove_edges{i};
               
                    %replace removed continues with global mean
                    len_of_sigma=length(temp_sigma_ia);
                    for gii=1:length(t_remove_variable)
                        for gkk=1:length(temp_u_ia)
                            t_u_ia=temp_u_ia{gkk};
                            t_u_ia(t_remove_variable(gii))=0; %mean(mean(continues_data(:,t_remove_variable) )); %mean(continues_data(:,t_remove_variable(gii)));
                            temp_u_ia{gkk}=t_u_ia;
                        end
                    
                        for jj=1:len_of_sigma        
                            t_sigma_ia=temp_sigma_ia{jj}; %at here we assume only one sigma in cell!!
                            t_idx=1:size(t_sigma_ia,1);
                            t_idx=setdiff(t_idx,t_remove_variable(gii));
                        
                            t_sigma_ia(t_remove_variable(gii),[t_idx])=0;
                            t_sigma_ia([t_idx],t_remove_variable(gii))=0;            
                            t_sigma_ia(t_remove_variable(gii),t_remove_variable(gii))=1; %mix_compute_sigma(continues_data(:,t_remove_variable(gii))); %1;   
                            temp_sigma_ia{jj}=t_sigma_ia;
                        end %end jj
                    end %end gii
                end
                %end added wang 05
                current_u_ia=temp_u_ia;
                current_sigma_ia=temp_sigma_ia;
                
                [fitted_n,fitted_u,fitted_sigma]=mix_fitted_HOMmoment(...
                    N,q,current_m_ia,current_sigma_ia,current_u_ia,ishom);

                %[i,j],fitted_sigma
                fitted_moment.record_fitted_sigma{i,j}=fitted_sigma;
                fitted_moment.record_fitted_n{i,j}=fitted_n;
                fitted_moment.record_fitted_u{i,j}=fitted_u;
                %fitted_p=fitted_n./N;
                %size(fitted_p)
                %size(fitted_sigma)
                fitted_temp_sigma=fitted_temp_sigma+fitted_n.*fitted_sigma./N;
            %end %end if fit
        end %end j
            %added wang
            if (istype(i)==2 | istype(i)==3)
            %both continues and discrete model are partial
                t_remove_variable=remove_edges{i};
                %replace removed continues with global mean/ 1 in sigma
                for gii=1:length(t_remove_variable)
                    fitted_temp_sigma(t_remove_variable(gii),t_remove_variable(gii))=1;   
                end
            end
            %end added
            record_fitted_sigma{i}=fitted_temp_sigma;
            record_obs_sigma{i}=obs_temp_sigma; 
    %end %end i
    
% for i=1:ia
%something error at here Oct 15 2005
 i=index;
    for j=1:sub_model_level(i)
        if cycle<=ia
             if   obs_moment.record_obs_n{i,j}>2.9E-38
                obs_moment.record_obs_sigma{i,j}=record_obs_sigma{i};
             else
                 obs_moment.record_obs_sigma{i,j}=zeros(size(record_obs_sigma{i}));
                 obs_moment.record_obs_n{i,j}=zeros(size(obs_moment.record_obs_n{i,j}));
                 obs_moment.record_obs_u{i,j}=zeros(size(obs_moment.record_obs_u{i,j}));
             end
        end
        if   fitted_moment.record_fitted_n{i,j}>2.9E-38 
            fitted_moment.record_fitted_sigma{i,j}=record_fitted_sigma{i};
        else
            fitted_moment.record_fitted_sigma{i,j}=zeros(size(record_fitted_sigma{i}));
            fitted_moment.record_fitted_n{i,j}=zeros(size(fitted_moment.record_fitted_n{i,j}));
            fitted_moment.record_fitted_u{i,j}=zeros(size(fitted_moment.record_fitted_u{i,j}));
        end
    end
%end
