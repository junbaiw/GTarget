function p=corrcoef2p(r,n)
%A simple test of significance of correlation coefficient
%r: correlation coefficient, n is the number of samples
%when p value < 0.001 then only report the p value as <0.001
%because it may unstable when compute the small p values.
%
t=r/sqrt( (1-r^2)/(n-2));
df=n-2;

%buzz function
t=abs(t);
rt=t/sqrt(n);
fk=atan(rt);
if n==1 
	p=1-fk/(pi/2);
else
	ek=sin(fk);
	dk=cos(fk);
	if mod(n,2)==1
		p=1-(fk+ek*dk*corrcoefZip(dk*dk,2,n-3,-1))/(pi/2);
	else
		p=1-ek*corrcoefZip(dk*dk,1,n-3,-1);
	end
end

	
 


