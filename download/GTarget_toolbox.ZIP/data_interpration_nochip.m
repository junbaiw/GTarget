function [vars,new_x,new_y]=data_interpration_nochip(tdata, data_idx,intervalue,sorted_x,tvars,num_of_tf,isfile)

t_data=tdata(:,data_idx);
sorted_y=t_data;
for i=1:size(t_data,1)
       new_x(i,:)=min(sorted_x):intervalue:max(sorted_x);
            %new_y(i,:)=interp1(sorted_x,sorted_y(i,:),new_x(i,:),'nearest');
       new_y(i,:)=interp1(sorted_x,sorted_y(i,:),new_x(i,:),'spline');
end
if isfile<5
    for k=1:(length(new_x(1,:))+num_of_tf)
       if k<=length(new_x(1,:))
           vars{k}=num2str(new_x(1,k));
       else
           vars{k}=tvars(end-num_of_tf+k-length(new_x(1,:)),:);
       end
    end
else
     for k=1:(length(new_x(1,:)))
           vars{k}=num2str(new_x(1,k));
     end
end