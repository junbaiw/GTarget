function [new_out_data,fitted_pij,fitted_uij,fitted_sigmaij,...
    delta_alpha,delta_beta,delta_omega,gema_n,temp_parm_diff,record_hom_sigma]=mix_MIPS_update(...
    fitted_pij,fitted_uij,fitted_sigmaij,...    
    N,q,gema_n,new_out_data,...
    current_alpha,current_beta,current_omega,delta_alpha,delta_beta,delta_omega,...
    temp_cell_idx,jj,temp_parm_diff,out_data,all_moments,record_hom_sigma)
%update the parameter in MIPS algorithm
%
%assume obs_p is zero then fittd_p is zero too oct 2005

for k=1:length(jj)
        j=jj(k);
        if ~isempty(delta_alpha{j})
            %clear t_current_alpha  t_current_beta  t_current_omega 
            [row,col]=size(current_alpha{j});
            new_alpha=cell(1,col);
            new_beta=cell(1,col);
            new_omega=cell(1,col);
            %temp_parm_diff=[]; %cell(1,sub_model_level(i));
            t_current_alpha=current_alpha{j};
            t_current_beta=current_beta{j};
            t_current_omega=current_omega{j};
            %delta_alpha,delta_beta,delta_omega
            new_delta_alpha{j}=gema_n*delta_alpha{j};
            new_delta_beta{j}=gema_n*delta_beta{j};
            new_delta_omega{j}=gema_n*delta_omega{j};
            %added wang
            
            for nl=1:col
                    new_alpha{nl}=t_current_alpha{nl}+new_delta_alpha{j};
                    new_beta{nl}=t_current_beta{nl}+new_delta_beta{j};           
                    new_omega{nl}=t_current_omega{nl}+new_delta_omega{j};
            end
            %end added
              
            temp_parm_diff(j)=max([abs(new_delta_alpha{j}),max(abs(new_delta_beta{j})),...
                max(max(abs(new_delta_omega{j})))]);
            
            %update parameter in output
            [new_n, new_u, new_sigma]=mix_canonical2monent_new(new_alpha,new_beta, new_omega,q,N);
            
            new_m_ia=cell(1,col);
            matrix_new_m_ia=[];
            idx_cell= [out_data{temp_cell_idx{j},4}]; %fitted cell
            idx_obs=all_moments.nij(temp_cell_idx{j}); %obsed cell
            for nl=1:col      
                if  sum(idx_obs)>0  & sum(idx_cell(nl))>0
                    new_m_ia{nl}=new_n{nl};
                    matrix_new_m_ia(nl)=new_n{nl};
                else
                    new_m_ia{nl}=zeros(size(new_n{nl}));
                    matrix_new_m_ia(nl)=zeros(size(new_n{nl}));
                  
                    new_u{nl}=zeros(size(new_u{nl}));
                    new_sigma{nl}=zeros(size(new_sigma{nl}));
                    
                    new_alpha{nl}=zeros(size(delta_alpha{j}));
                    new_beta{nl}=zeros(size(delta_beta{j}));           
                    new_omega{nl}=zeros(size(delta_omega{j}));
                end
            end
            
            %added wang
            new_out_data(temp_cell_idx{j},1)=new_alpha;
            new_out_data(temp_cell_idx{j},2)=new_beta;
            new_out_data(temp_cell_idx{j},3)=new_omega;
 	      
                new_out_data(temp_cell_idx{j},4)=new_m_ia;
                new_out_data(temp_cell_idx{j},5)=new_u;
                new_out_data(temp_cell_idx{j},6)=new_sigma;
           
                temp_pij=matrix_new_m_ia./N;
                fitted_pij(temp_cell_idx{j})=temp_pij;
                fitted_uij(temp_cell_idx{j})=new_u;
                fitted_sigmaij(temp_cell_idx{j})=new_sigma;
                if sum(sum(new_sigma{1}))~=0;
                   record_hom_sigma=new_sigma{1}; 
                end
     end % end if
end %end for k
