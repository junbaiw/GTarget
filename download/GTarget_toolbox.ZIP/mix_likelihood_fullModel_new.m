function Ls=mix_likelihood_fullModel_new(N,tt_nij,q,tt_uij,tt_sigmaij)
%Input N, n, q and Sij is sum of squares
%nij Tij is matrix,Sij is cell

%added wang
%find empty cell in nij
%digits(64);
idx=find(tt_nij>2.9E-38); %3.7201e-44); %~=0);
t_sigmaij=cell(1,length(idx));
t_nij=tt_nij(idx);
t_uij=tt_uij(idx,:);
t_sigmaij={tt_sigmaij{idx}};
%end added oct 2005

[row,col]=size(t_nij);
%compute part_a=ni*log(ni/N)
part_a=0;
t_pij=t_nij./N;
%t_pij(find(t_pij==0))=1;
part_a=sum(sum(t_nij.*log(t_pij)));
%part_a=sum(sum(t_nij.*log(t_nij./N)));

%compute part_b=ni*log(Si)/2
part_b=0;
for i=1:row
	t_det=det(t_sigmaij{i});
    if t_det>0 %2.9E-38 %3.7201e-44 
        part_b=part_b+sum(sum(t_nij(i,:).*log(t_det) ))./2;
    end
        
end
Ls=part_a-N*q*log(2*pi)/2-part_b-N*q/2;



%%%%%%%%%%%%
%l_n=length(tnij.*log(nij./N)_nij);
%Ls=0;
%part_a=0;
%part_b=0;
%for i=1:l_n%
%	nij=t_nij{i};%
%	Sij=t_Sij{i};
%	Tij=t_Tij{i};	
%	sigma=Sij./nij-(Tij./nij).^2
%	t_Ls=sum(sum(nij.*log(nij./N)))-N*q*log(2*pi)/2-sum(sum(nij.*log(sigma)))/2-N*q/2;
%	part_a=part_a+sum(sum(nij.*log(nij./N)));
%	part_b=part_b+sum(sum(nij.*log(abs(sigma))))/2;
%end
%part_a
%part_b
%-N*q*log(2*pi)/2
%-N*q/2
%Ls=part_a-N*q*log(2*pi)/2-part_b-N*q/2;

