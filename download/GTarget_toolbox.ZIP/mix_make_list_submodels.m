function hom_submodel=mix_make_list_submodels(generate_class) 
%make a list of submodels
%
	hom_submodel={};
        idx=0;
        field_name=fieldnames(generate_class);

        if ismember('k',field_name)
                if ~isempty(generate_class.k)
                        if idx>0
                                idx=idx;
                        else
                                idx=1;
                        end
                        for i=1:length(generate_class.k)
                                hom_submodel{idx}=generate_class.k{i};
                                idx=idx+1;
                        end
                end
        end

   if ismember('h',field_name)
                if ~isempty(generate_class.h)
                        if idx>0
                                idx=idx;
                        else
                                idx=1;
                        end
                        for i=1:length(generate_class.h)
                                hom_submodel{idx}=generate_class.h{i};
                                idx=idx+1;
                        end
                end
   end

        
        if ismember('g',field_name)
                if ~isempty(generate_class.g)
                        idx=1;
                        for i=1:length(generate_class.g)
                                hom_submodel{idx}=generate_class.g{i};
                                idx=idx+1;
                        end
                end
        end

     