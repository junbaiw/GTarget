function centers=find_optimizeClusterWithChipSeq(sq_match,exp_data,chp_data,norm_data,casenames)
for idd=1:1
    %random permutation of miss match data
    %sequence match
    %file1='cellCycle_data/cycle_exp_plus_seqMatch_0missmatch.txt'
    %[sdata,svar,scase]=tblread(file1,'\t');
    %sq_match=sdata;
    %(sdata(:,end-7:end));
    %expression and chip data
    %file2='cellCycle_data/cycle_exp_plus_chip.csv'
    %[edata,evar,ecase]=tblread(file2,'\t');
    %exp_data=edata(:,1:end-9);
    %chp_data=(edata(:,end-7:end));
    
    %norm_data=som_normalize(exp_data,'var');
    %casenames=ecase;
   
    scase=casenames;

for kk=8:30 %length(record_member)
   % rand('state',0);
   % rand('seed',1);
    %cluster_exp_data=record_center{kk};
    centers(1)=kk;
    %fine turning of the center
    beta=1.5;
    epochs=500;
    x=norm_data;
    y0=(rand(kk,size(x,2))-0.5)*10e-5; %record_center{kk}; %    record_center{min_idx+1};
    c=size(y0,1);
    [fuzzy_center1, fuzzy_member1]=fuzzy_nGas(x,y0,c,beta,epochs);
    disp('Fine turning of center')
    prototype=fuzzy_center1;
    Cp=[1:centers(1)]';
    %3) use knn to find  the best clusters for each center from nGas
    d=sqrt(som_eucdist2(x,prototype));
    d(eye(size(d))==1)==NaN;
    K=1;    
    beta=1.5;
    [c P]=fuzzy_knnnew(d,Cp,K,beta);
    %cluster_cases=prototype_cases;
    prototype_name={};
    prototype_cases={};
    prototype_data=[];
    is_data=1;
    for i=1:kk % 15 prototype    
        %casenames(i,:)
        temp=P(:,i);
        idx=find(temp>0);
        tempP=temp(idx,:);
        tempy=casenames(idx,:)
        if ~isempty(tempy)
            prototype_cases{is_data}=tempy;
            %prototype_name{is_data}=names;
            prototype_data(is_data,:)=prototype(i,:);
            is_data=is_data+1;
        end
    end
    cluster_exp_data=prototype_data;
    cluster_cases=prototype_cases;
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%make cluster's sq_match
clear cluster_chip_data cluster_sq_match
for k=1:length(prototype_cases)
    tmp=prototype_cases{k};
    [cc ai bi]=intersect(cellstr(tmp),cellstr(scase));
    size(sq_match),bi
    cluster_sq_match(k,:)=sum((sq_match(bi,:)),1);  %sum of cluter motif count
    cluster_chip_data(k,:)=sum(2.^chp_data(bi,:),1); %sum of cluster chip oppocuency
end

cluster_chip_data=som_normalize(cluster_chip_data,'var');
%cluster_exp_data=som_normalize(cluster_exp_data','var')';
cluster_sq_match=som_normalize(cluster_sq_match,'var');
%gene activitation profile
M=cluster_chip_data;
E=cluster_exp_data; %som_normalize(cluster_exp_data','var')';
[u,s,v]=svd(M);
A=v*inv(s'*s)*s'*u'*E;
% A=pinv(M)*E;
 
%estimated expression
esp_e=A'*cluster_sq_match';
%esp_e=A'*cluster_chip_data';
norm_esp_e=som_normalize(esp_e,'var'); %error at here !!! April 15 ?I have to find a better way to measure this error
cutoff=0.05
good_ones=0;
all_ones=size(prototype_data,1)
close all
for k=1:size(prototype_data,1)
    figure(2)
    subplot(ceil(size(prototype_data,1)/2),2,k)
    %clf
    p2=plot(norm_esp_e(:,k),'r-')
    hold on
    p1=plot(cluster_exp_data(k,:),'k--')
    %legend([p1,p2],'Measured Expression','Estimated Expression');
    %
    %nlevels =10;
    %redgreen = makecolormap(nlevels);
    %cmin = -2; % measured in standard deviations if scale=1
    %cmax =  2; % measured in standard deviations if scale=1
    plot_data2=[norm_esp_e(:,k),cluster_exp_data(k,:)']';
    %titstr=[];
    %temp_x=num2str([1:size(plot_data2,2)]');
    %temp_y=['este';'real']
    %datasize=size(plot_data2);
    %tempP=1;
    %figno=2;
    %plotdata(plot_data2,redgreen,cmin,cmax,figno,titstr,0,...
    %    temp_x,temp_y,datasize,num2str([1;tempP]));
    cc=corrcoef(plot_data2')
    pp=corrcoef2p(cc(1,2),73)/2; %one-tailed test
   
    [h p]=ttest2(plot_data2(1,:),plot_data2(2,:))
   % title(['Cluster ',num2str(k), ' Measured Expression vs. Estimated Expression ', ...
   %     ' CorrCoef= ',num2str(cc(1,2))])
   title(['Cluster',num2str(k),' r=',num2str(cc(1,2)),' (p=',num2str(pp),')'])
   % xlabel('Experimental Conditions')
    ylabel('Expression profiles')
     % print('-dpsc','-r200',['seq_','cluster',num2str(k)]);
      max_y=max(max([plot_data2(1,:),plot_data2(2,:)]))+1/2;
    min_y=min(min([plot_data2(1,:),plot_data2(2,:)]))-1/2;
    axis([0 73 min_y max_y])
    if (pp<0.05 & cc(1,2)>0)
        good_ones=good_ones+1;
    end
   %pause
end
percent_good(idd,kk)=good_ones/all_ones
 
end % end kk
end % end idd

[maxv,maxidx]=max(percent_good);
centers=maxidx(1);