function generate_class=mix_make_model_subspace_new(full_discrete,full_discrete_sublevel,full_continues,submodel)
%make subspace or set of models for mixed graphical models d/l/q
%subspace set (a,d) a is discrete variable, d is continues variables
%
%full_discrete={'AB'};
%full_discrete_sublevel=[2,3];
%full_continues={'XY'};
%dis_g={'A','B'}
%lin_h={'BY','BX'}
%qud_k={'X','Y'}

dis_g=submodel.d_model;
lin_h=submodel.l_model;
qud_k=submodel.q_model;
len_of_dis=length(dis_g);
len_of_lin=length(lin_h);
len_of_qud=length(qud_k);

%subspace set subset{discrete, continues}
%currently, only consider the homgenouse model
subset={};
idx=1;
%consider full discrete sets
for i=1:len_of_dis
	for j=1:len_of_qud
		cont_qud=intersect(num2str(qud_k{j}),strvcat(full_continues));
		subset{idx}={dis_g{i}, cont_qud};
		idx=idx+1;
	end
end

%extend all discrete model to all possibile submodels i.e. ABCD-> A,B,C,D, AB,AC,AD,BC,BD,CD,ABC,ABD,ACD,BCD
%consider full-1 discrete sets
idx=1;
dist_subset={};
for i=1:len_of_dis
	temp_subset=strvcat(dis_g{i});
	len_temp=length(temp_subset);
  	for j=1:len_temp-1
		temp_dist_subset=[];
		temp_dist_subset=combnk(1:len_temp,j);
		len_temp_dist=size(temp_dist_subset,1);
		for k=1:len_temp_dist
			dist_subset{idx}=temp_subset(temp_dist_subset(k,:));
			idx=idx+1;	
		end
	end
end
uniq_dist_subset=unique(dist_subset);

%make the rest of discrete set if it belong to linear model
idx=1;
len_subset=length(uniq_dist_subset);
subset2={};
for i=1:len_subset
	if sum(ismember(uniq_dist_subset{i},strvcat(lin_h)))/length(uniq_dist_subset{i})==1
		for j=1:len_of_qud
                	cont_qud=intersect(num2str(qud_k{j}),strvcat(full_continues));
			subset2{idx}={uniq_dist_subset{i}, cont_qud };
			idx=idx+1;
		end
	end
end

%now start to generate subspace of subset and subset2 based on linear models
idx=1;
%here only for homenouge models
generate_class.k=qud_k;
idx=1;
for i=1:length(subset) 
	sub_dis=subset{i}{1};
	sub_con=subset{i}{2};
	%find loccation of match to sub_dis
	temp_submodel=strvcat(lin_h(find(sum(ismember(strvcat(lin_h),sub_dis),2)./length(sub_dis)==1)));
	temp_con=temp_submodel(find(ismember(temp_submodel,sub_dis)==0 & ismember(temp_submodel,strvcat(sub_con))==1 ) );
	temp_con=reshape(temp_con,1,length(temp_con));
	new_class_h{idx}=strvcat([sub_dis,temp_con]);
	idx=idx+1;
end
if ~isempty(subset2)
	for i=1:length(subset2)
        	sub_dis=subset2{i}{1};
        	sub_con=subset2{i}{2};
        	%find loccation of match to sub_dis
        	temp_submodel=strvcat(lin_h(find(sum(ismember(strvcat(lin_h),sub_dis),2)./length(sub_dis)==1)));
        	temp_con=temp_submodel(find(ismember(temp_submodel,sub_dis)==0 & ismember(temp_submodel,strvcat(sub_con))==1 ));
        	temp_con=reshape(temp_con,1,length(temp_con));
        	new_class_h{idx}=strvcat([sub_dis,temp_con]);
            %if length(subset2)>100
                new_class_h=mix_remove_overlap_subsets(new_class_h,full_discrete,full_continues);
            %end
        	idx=length(new_class_h)+1;
	end
end
uniq_new_class_h=unique(new_class_h);
temp_class=mix_remove_overlap_subsetsAll(uniq_new_class_h,full_discrete,full_continues);
test_generate_class.h={};
test_generate_class.h=temp_class;
generate_class.h=test_generate_class.h;
        
