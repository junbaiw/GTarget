function  [dissimilar_density, minCluster_distance,chtest,total_degreeF]=stress_forCluster_centers(...
    fuzzy_centerOld,fuzzy_center,itc,msize,msizeold)
if itc==2
	dX0=1-corrcoef2(fuzzy_centerOld.data);
	dfold=size(fuzzy_centerOld.data,1);
else
	dX0=1-corrcoef2(fuzzy_centerOld.codebook);
	dfold=size(fuzzy_centerOld.codebook,1);
end

delt=1-corrcoef2(fuzzy_center.codebook);
df=size(fuzzy_center.codebook,1);
sample_size=size(fuzzy_center.codebook,2);

sigma_X0=(sum(sum(triu(delt.^2))+sum(triu(dX0.^2))-2*sum(triu(delt).*triu(dX0)))./sum(sum(triu(delt.^2))));

%sigma_X0=abs(sample_size*log(det(dX0)/det(delt)));
%this term is not good
distof_cluster_center=sqrt(som_eucdist2(fuzzy_center.codebook,fuzzy_center.codebook));
full_idx=find(triu(distof_cluster_center)>0.0001);
%little bug at herei
%possibile delete very close distance, but it's difficult extract distance from index
%I have to check it later
all_dist=distof_cluster_center(full_idx);
mindist=min(all_dist);
maxdist=max(all_dist);
max_min=mindist;
if isempty(mindist)
  mindist=0;
end

dissimilar_density=sigma_X0;
minCluster_distance=mindist;
degreeF=abs(dfold-df);
degreeF=(msize-msizeold)-1;
d_idx=find((degreeF<0)|(degreeF==0));
degreeF(d_idx)=1; %replace -1 degree as 1
total_degreeF=degreeF(1);
chtest=Chisq(sigma_X0,total_degreeF);
