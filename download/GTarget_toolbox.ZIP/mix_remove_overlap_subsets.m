function temp_class=mix_remove_overlap_subsets(uniq_new_class_h,full_discrete,full_continues)
%start to remove potentional overlap models
%current function only chick the last element against the whole sets 
%for overlap subsets. It is easy to change this function to a golable
%search!
test_generate_class.h=uniq_new_class_h;
len_h=length(test_generate_class.h);
test_generate_class.idx=zeros(1,len_h);
%for gi=1:len_h-1
    %for gj=gi+1:len_h
gi=1;
isbreak=0;
while gi<=len_h-1
    for gj=len_h
        temp_model_dis=intersect(test_generate_class.h{gi},strvcat(full_discrete));
        temp_model_con=intersect(test_generate_class.h{gi},strvcat(full_continues));
        temp_model2_dis=intersect(test_generate_class.h{gj},strvcat(full_discrete));
        temp_model2_con=intersect(test_generate_class.h{gj},strvcat(full_continues));
   
        insect_class_dis=intersect(temp_model_dis,temp_model2_dis);
        ism1_dis=sum(ismember(insect_class_dis,temp_model_dis));
        ism2_dis=sum(ismember(insect_class_dis,temp_model2_dis));
        
        insect_class_con=intersect(temp_model_con,temp_model2_con);
        ism1_con=sum(ismember(insect_class_con,temp_model_con));
        ism2_con=sum(ismember(insect_class_con,temp_model2_con));
       
        
        if (~isempty(insect_class_dis) & ism1_dis==ism2_dis & ...
                (ism1_dis==length(temp_model_dis) | ism2_dis==length(temp_model2_dis))) & ...
                (~isempty(insect_class_con) & ism1_con==ism2_con & ...
                (ism1_con==length(temp_model_con) | ism2_con==length(temp_model2_con)))
            %disp('inside')
           if length(temp_model_dis)>=length(temp_model2_dis) & ...
                   length(temp_model_con)>=length(temp_model2_con)
                %test_generate_class.idx(gi)=0; %should keep
                test_generate_class.idx(gj)=1; %should remove
                %disp('remove')
                isbreak=1;
                break;
           elseif length(temp_model_dis)<=length(temp_model2_dis) & ...
                   length(temp_model_con)<=length(temp_model2_con)
                test_generate_class.idx(gi)=1; %
                %test_generate_class.idx(gj)=0; %
               % disp('remove 2')
                isbreak=1;
                break;
           end %end if
        elseif ( ~isempty(insect_class_dis) & ism1_dis==ism2_dis & ...
                 (ism1_dis==length(temp_model_dis) | ism2_dis==length(temp_model2_dis)) ) & ...
                 (isempty(insect_class_con) & ( isempty(temp_model_con) | isempty(temp_model2_con)) ...
                )
            %disp('inside2')
            %[ test_generate_class.h{gi},':', test_generate_class.h{gj}]
            if length(temp_model_dis)>=length(temp_model2_dis) & ...
                   isempty(temp_model2_con)
                %test_generate_class.idx(gi)=0; %should keep
                test_generate_class.idx(gj)=1; %should remove
                %disp('remove21')
                isbreak=1;
                break;
           elseif length(temp_model_dis)<=length(temp_model2_dis) & ...
                   isempty(temp_model2_con)
                test_generate_class.idx(gi)=1; %
                %test_generate_class.idx(gj)=0; %
                %disp('remove 22')
                isbreak=1;
                break;
            end
            
        end %end if
     end %end gj
     if isbreak==1
         break;
     end
     gi=gi+1;
%	[gi gj]
end %end gi
temp_class=test_generate_class.h([find(test_generate_class.idx==0)]);
