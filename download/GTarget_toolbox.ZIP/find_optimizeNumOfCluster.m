function centers=find_optimizeNumOfCluster(loops,n,dim,x)
for ik=1:loops
for i=2:n
    c=i;
    y0=(rand(c,dim)-0.5)*10e-5;
    beta=1.5;
    epochs=500;
    [fuzzy_center1, fuzzy_member1]=fuzzy_nGas(x,y0,c,beta,epochs);
 
    fuzzy_centerOld.data=x;
    fuzzy_centerOld.codebook=x;
    old_msize=n;
    fuzzy_center.data=x;
    fuzzy_center.codebook=fuzzy_center1;
    msize=c;
    itc=i;
    [dissimilar_density, minCluster_distance,chtest,df]=stress_forCluster_centers(...
       fuzzy_centerOld,fuzzy_center,itc,msize,old_msize);
    dis(i)=dissimilar_density
    p(i)=chtest;
    degF(i)=df;
    delta_dis(i)=abs(dis(i)-dis(i-1));
    record_center{i}=fuzzy_center1;
    record_member{i}=fuzzy_member1;
end
  [min_dis,min_idx]=min(dis(2:end));                                                                          
  tcenters=size(record_center{min_idx+1});  
  loop(ik,:)=tcenters
  loop_centers{ik}=record_center{min_idx+1};
end %end ik
centers=ceil(median(loop(:,1)));