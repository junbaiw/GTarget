function [fitted_n_ia,fitted_u,fitted_sigma]=mix_fitted_HOMmoment(...
    N,q,t_m_ia,t_sigma_ia,t_u_ia,ishom)
%Input fitted m_ia, sigma_ia, u_ia
%m_ia is matrix, sigma_ia, u_ia is cell
%ishom=1 is homogeneous model
%ishom=0 is heterogeneous model
%Compute fitted n,u,sigma for fitted homougenous model
%
%format long e
warning off;

%added wanf
idx_good=find(t_m_ia>2.9E-38); %3.7201e-44);
m_ia=t_m_ia(idx_good);
u_ia=cell(1,length(idx_good));
u_ia={t_u_ia{idx_good}};
sigma_ia=cell(1,length(idx_good));
sigma_ia={t_sigma_ia{idx_good}};
%end wang
if ~isempty(idx_good)
    [row col]=size(m_ia);
    fitted_n_ia=sum(sum(m_ia));
    fitted_T_ia=zeros(size(u_ia{1}));
    fitted_S_ia=zeros(size(sigma_ia{1}));
    for i=1:col
        %m_ia(i), u_ia{i}
        fitted_T_ia= fitted_T_ia+ (m_ia(i).*u_ia{i});
        fitted_S_ia= fitted_S_ia+ (m_ia(i).*(sigma_ia{i}+u_ia{i}*u_ia{i}'));
    end
    %I found the bug june 2005!! at here 
    fitted_u=(fitted_T_ia./fitted_n_ia);
    %fitted_u(find(abs(fitted_u)==inf))=0;
    %fitted_u(find(isnan(abs(fitted_u))))=0;
    fitted_sigma=(fitted_S_ia./fitted_n_ia-(fitted_u*fitted_u'));
    %fitted_sigma(find(abs(fitted_sigma)==inf))=0;
    %fitted_sigma(find(isnan(abs(fitted_sigma))))=0;
    %fitted_p=fitted_n_ia./N;
    %added wang
    fitted_sigma(find(fitted_sigma>=0.9999 & fitted_sigma<=1.0))=1;
    %fitted_p(find(fitted_p>=0.9999 & fitted_p<=1.0))=1;
    %end added
else
    fitted_n_ia=0;
    fitted_u=zeros(max(size(t_u_ia{1})),1);
    fitted_sigma=zeros(size(t_sigma_ia{1}));
end
    
