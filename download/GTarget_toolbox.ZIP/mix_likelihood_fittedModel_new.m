function Lm=mix_likelihood_fittedModel_new(N,tt_obs_pij,tt_obs_uij,tt_obs_sigmaij,q,...
    tt_fitted_pij,tt_fitted_uij,tt_fitted_sigmaij)
%input u is the fitted mean, sigma is fitted variance, pij is fitted P
%real_S is real variance, Y is the real mean, n is the real count
%nij,pij are matrix, Sij,Tij,u,sigma is cell
warning off;
%digits(64);
%tt_obs_pij,
%tt_fitted_pij
%added wang
%find empty cell in nij and fitted_nij 3.7201e-44
bad_idx=intersect(find(tt_obs_pij<=2.9E-38),find(tt_fitted_pij<=2.9E-38));
good_idx=setdiff(1:length(tt_obs_pij),bad_idx);

idx=good_idx; %1:length(tt_obs_pij);    %find(tt_obs_pij>3.7201e-44); %~=0);
obs_sigmaij=cell(1,length(idx));
obs_pij=tt_obs_pij(idx);
obs_uij=tt_obs_uij(idx,:);
obs_sigmaij={tt_obs_sigmaij{idx}};

%there is a bug here fit_idx did not equal idx ?? Oct 2005
fit_idx=idx; %find(tt_fitted_pij>=0);
fitted_sigmaij=cell(1,length(fit_idx));
fitted_uij=cell(1,length(fit_idx));

fitted_pij=tt_fitted_pij(fit_idx);
fitted_uij={tt_fitted_uij{fit_idx}};
fitted_sigmaij={tt_fitted_sigmaij{fit_idx}};
%end added oct 2005

nij=reshape(obs_pij.*N,length(obs_pij),1);
pij=reshape(fitted_pij,length(fitted_pij),1);
[row col]=size(nij);
%compute part_a=ni*log(ni/N)
part_a=0;
npij=nij.*log(pij);
npij(find(abs(npij)==inf))=0;
npij(find(isnan(abs(npij))))=0;
part_a=sum(sum(npij));

%compute part_b=ni*log(Si)/2
part_b=0;
for i=1:row
        t_nij=obs_pij(i)*N;
        Y=reshape(obs_uij(i,:),length(obs_uij(i,:)),1);
        real_S=obs_sigmaij{i};
        
        t_u=fitted_uij{i};
        t_u=reshape(t_u,length(t_u),1);
        t_sigma=fitted_sigmaij{i};
        part_bb=det(t_sigma);
    
    if part_bb>0 %2.9E-38 %3.7201e-44
      part_b=part_b+sum(sum(t_nij.*log(part_bb) ))./2+sum(sum(t_nij.*trace(real_S*pinv(t_sigma))/2))...
             +sum((t_nij.*(Y-t_u)'*pinv(t_sigma)*(Y-t_u) ))./2;
    end
end
Lm=part_a-N*q*log(2*pi)/2-part_b;

%real_S=Sij./nij-(Tij./nij).^2;
%Y=Tij./nij;
%Lm=sum(sum(nij.*log(pij)))-N*q*log(2*pi)/2-sum(sum(nij.*log(sigma)))/2 ...
%-sum(sum(nij.*(real_S./sigma)))/2-sum(sum(nij.*(Y-u)./sigma.*(Y-u)))/2;
