function [new_out_data,fitted_pij,fitted_uij,fitted_sigmaij,temp_parm_diff,max_parm_diff]=mix_update_parameter...
    (i,sub_model_level,cell_idx,out_data,obs_moment,fitted_moment,convergens,gema_n,q,N,...
    fitted_pij,fitted_uij,fitted_sigmaij,new_out_data,temp_parm_diff,all_moments,...
    current_alpha,current_beta,current_omega,delta_alpha,delta_beta,delta_omega)
%update the parameter for stephalf algorithm
%
max_parm_diff=[];
for j=1:sub_model_level(i)
            %add wang
            %loop in sublevel of each ia
            %clear obs_alpha obs_beta obs_omega fitted_alpha fitted_beta fitted_omega delta_alpha delta_beta delta_omega
            obs_alpha=[];
            obs_beta=[];
            obs_omega=[];
            fitted_alpha=[];
            fitted_beta=[];
            fitted_omega=[];
            temp_cell=[];
            current_ia=i;
            current_ia_level=j;
            temp_cell=cell_idx{i};
            if iscell(temp_cell)
		        temp_cell_idx{j}=temp_cell{current_ia_level};
            else
                temp_cell_idx{j}=temp_cell(current_ia_level);
            end
            %add wang oct 2005 find empty cell
          
            [row,col]=size(current_alpha{j});
  
            %clear obs_n obs_u obs_sigma
            obs_n=[];
            obs_u=[];
            obs_sigma=[];
            obs_n=obs_moment.record_obs_n{i,j};
            obs_u=obs_moment.record_obs_u{i,j};
            obs_sigma=obs_moment.record_obs_sigma{i,j};
		
            fitted_n=fitted_moment.record_fitted_n{i,j};
            fitted_u=fitted_moment.record_fitted_u{i,j};
            fitted_sigma=fitted_moment.record_fitted_sigma{i,j};
 	   
            delta_m_ia=abs(obs_n-fitted_n);
            delta_u_ia=max(max(abs(obs_u-fitted_u)));
            delta_sigma_ia=max(max(abs(obs_sigma-fitted_sigma)));
            max_parm_diff(j)=max([delta_m_ia/sqrt(fitted_n+1),delta_u_ia,delta_sigma_ia]);
               
            obs_sigma(find(obs_sigma>=0.9999 & obs_sigma<=1.0))=1;
            fitted_sigma(find(fitted_sigma>=0.9999 & fitted_sigma<=1.0))=1;
                  			
            [new_out_data,fitted_pij,fitted_uij,fitted_sigmaij,delta_alpha,delta_beta,delta_omega,...
                        gema_n,temp_parm_diff]=mix_MIPS_update(...
                        fitted_pij,fitted_uij,fitted_sigmaij,...
                        N,q,gema_n,new_out_data,current_alpha,current_beta,current_omega,...
                        delta_alpha,delta_beta,delta_omega,temp_cell_idx,j,temp_parm_diff,out_data,all_moments);
                
end %end j
        
       
        