function redgreen = makecolormap(nlev);

%make red/green color map
%nlev = 10;
for i=1:nlev,
  redgreen(i,:)      = [0,(nlev-i+1)*(1.0/nlev),0]; 
end
redgreen(nlev+1,:) = [0,0,0];
for i=1:nlev,
  redgreen(nlev+1+i,:) = [i*(1.0/nlev),0,0];
end

return;
