


Notes:
1) Five demos are included in the GTarget toolbox.

2) For current Mixed Graphical Models, it only supports no more than 36 discrete variables.

3) Both Gaussian Graphical models and Mixed Graphical models will need a significant amount of CPU time when the number of variables is large.

4) Some sub-functions of the present GTarget were borrowed from other matlab toolbox such as MARRAY toolbox, MGRAPH toolbox and free SOM Toolbox for MATLAB.