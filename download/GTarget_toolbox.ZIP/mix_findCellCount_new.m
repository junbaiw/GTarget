function [nij, Tij, Sij,uij,sigmaij,new_cell_location]=mix_findCellCount_new(cell_location, discrete_data,continues_data,N)
%Input: cell_location, discrete_data, continues_Data, N is total number of data point
%Output: nij is count, Sij is sum of square , Tij is total , uij is mean, sigmaij is covariance 
%find each cell's nij, Tij and Sij -Method 2
%and each cell's n, u, sigma
idx=1;
[dis_row, dis_col]=size(discrete_data);
[con_row,con_col]=size(continues_data);

for kk=1:size(cell_location,1)
        temp_location=cell_location(kk,:);
	%find row index for current temp_location
       	temp_ni=find(sum(abs(discrete_data-repmat(temp_location,N,1)),2)==0);
         if ~isempty(temp_ni)
            nij(idx,:)=length(temp_ni);
        	t_Tij=sum(continues_data(temp_ni,:),1);
        	t_Sij=continues_data(temp_ni,:)'*continues_data(temp_ni,:);
            Tij(idx,:)=t_Tij;
        	Sij{idx}=t_Sij;
            
    		uij(idx,:)=t_Tij./nij(idx,:);
            t_sigma=t_Sij./nij(idx,:)-uij(idx,:)'*uij(idx,:);
            sigmaij{idx}=t_sigma;
            new_cell_location(idx,:)=temp_location;
            idx=idx+1;
         else
             %added wang
             nij(idx,:)=0;
             Tij(idx,:)=zeros(1,con_col);
             Sij{idx}=zeros(con_col,con_col);
             uij(idx,:)=zeros(1,con_col);
             sigmaij{idx}=zeros(con_col,con_col);
             new_cell_location(idx,:)=temp_location;
             idx=idx+1;
         end
        
end %end kk

