function dim=mix_degree_of_freedom_new2(full_discrete,full_discrete_sublevel,full_continues,submodels)
%homenogenous model is fine
%the computation of degree of freedom is based on lazens' book 'Graphical
%models', in chapter 'mixed models'

%but hetergenous model is wrong
%clear all
%full_discrete={'AB'};
%full_discrete_sublevel=[2,3];
%full_continues={'XY'};
%dis_g={'A','B'}
%lin_h={'BY','BX'}
%qud_k={'X','Y'}

field_name=fieldnames(submodels);
if ismember('g',field_name)
    dis_g=submodels.g;
elseif ismember('d_model',field_name)
    dis_g=submodels.d_model;
else
    dis_g={};
end


if ismember('h',field_name)
    lin_h=submodels.h;
elseif ismember('l_model',field_name)
    lin_h=submodels.l_model;
else
    lin_h={};
end

if ismember('k',field_name)
    qud_k=submodels.k;
elseif ismember('q_model',field_name)
    qud_k=submodels.q_model;
else
    qud_k={};
end
%first remove redundant models
%currently only for hetergenous model!
len_of_dis=length(dis_g);
len_of_lin=length(lin_h);
len_of_qud=length(qud_k);

%g vs. h
generate_class1={};
k=1;
for i=1:len_of_dis
    temp_g_model=dis_g{i};
    num_of_overlap=0;
    for j=1:len_of_lin
        temp_h_model=lin_h{j};
        diff_g_h=setdiff(temp_g_model,temp_h_model);
        if isempty(diff_g_h)
            num_of_overlap=num_of_overlap+1;
        end
    end
    if num_of_overlap==0
        generate_class1{k}=temp_g_model;
        k=k+1;
    end
end

%g1 vs. k
generate_class2={};
k=1;
for i=1:length(generate_class1)
    temp_g_model=generate_class1{i};
    num_of_overlap=0;
    for j=1:len_of_qud
        temp_k_model=qud_k{j};
        diff_g_k=setdiff(temp_g_model,temp_k_model);
        if isempty(diff_g_k)
            num_of_overlap=num_of_overlap+1;
        end
    end
    if num_of_overlap==0
        generate_class2{k}=temp_g_model;
        k=k+1;
    end
end

%h vs. k
k=1;
generate_class3={};
for i=1:len_of_lin
    temp_h_model=lin_h{i};
    num_of_overlap=0;
    for j=1:len_of_qud
        temp_k_model=qud_k{j};
        diff_h_k=setdiff(temp_h_model,temp_k_model);
        if isempty(diff_h_k)
           num_of_overlap=num_of_overlap+1;
        end
    end
    if num_of_overlap==0
        generate_class3{k}=temp_h_model;
        k=k+1;
    end
end

%this is only valied for hetergenous model!
if ~isempty(generate_class2)
    %discrete
    for i=1:length(generate_class2)
        generate_class.g{i}=generate_class2{i};
    end
end
if ~isempty(generate_class3)
    %linear
    for i=1:length(generate_class3)
        generate_class.h{i}=generate_class3{i};
    end
end
if ~isempty(qud_k)
    %quardic
    generate_class.k=qud_k;
end

%This is the subspace used to calculate the degree of freedom and compute LL
%generate_class
%pause
%now start to compute degree of freedom
field_str=fieldnames(generate_class);
if ismember('k',field_str)
	%assign quadratic continues variable as x^2
	len_of_k=length(generate_class.k);
	for i=1:len_of_k
		temp_k=generate_class.k{i};
		k_model{i}=[strvcat(intersect(strvcat(temp_k),strvcat(full_continues))),...
					strvcat(intersect(strvcat(temp_k),strvcat(full_continues))),strvcat(intersect(strvcat(temp_k),strvcat(full_discrete)))];
	end
else
	k_model={};
end
dimMF={};
if ismember('g',field_str)
	dimMF=union(generate_class.g,dimMF);
end
if ismember('h',field_str)
	  dimMF=union(generate_class.h,dimMF);
end
if ismember('k',field_str)
	dimMF=union(k_model,dimMF);
end
%initial models
all_dimMF{1}=dimMF;
%[all_dimMF{1:end}]
%pause

%expand the models
[all_dimMF,len_dimMF,record_all_dimMF_sign,record_all_dimMF_coef,dim]=mix_subspace_expanding_new(all_dimMF,full_discrete,full_discrete_sublevel,...
full_continues);

%compute degree of freedom
dim=mix_compute_degree_of_freedom_new(all_dimMF,len_dimMF,record_all_dimMF_sign,record_all_dimMF_coef,full_discrete,full_discrete_sublevel,full_continues);
