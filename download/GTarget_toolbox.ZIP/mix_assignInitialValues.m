function [fitted_pij,fitted_uij,fitted_sigmaij,out_data]=mix_assignInitialValues(N,cell_location,num_of_continues,num_of_discrete,levels,nij,mean_AB)
%Input : N, cell_location, num_of_continues, num_of_discrete, levels, nij, mean_AB is mean of each discret column 
%Output: fitted_pij, fitted_uij, fitted_sigmaij,  out_data 
q=num_of_continues; % q is the number of continues variables
d=num_of_discrete; %num of discretes variables
kd=levels; %each discrete variable's level
k=1; %index of models
ia=d;
%assign initital moment values
m_ia=1;
p_ia=1/prod(size(nij));
sigma_ia=eye(q,q);
u_ia=reshape(mean_AB,length(mean_AB),1);
for i=1:length(cell_location)
         [alpha_ia beta_ia omega_ia]=mix_moment2canonical_new2(p_ia*N,u_ia,sigma_ia,q,N);
         out_data{i,1}=alpha_ia;
         out_data{i,2}=beta_ia;
         out_data{i,3}=omega_ia;
         out_data{i,4}=p_ia.*N;
         out_data{i,5}=u_ia;
         out_data{i,6}=sigma_ia;
         fitted_pij(i)=p_ia;
         fitted_uij{i}=u_ia;
         fitted_sigmaij{i}=sigma_ia;
end

