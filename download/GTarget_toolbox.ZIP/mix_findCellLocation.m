function cell_location=mix_findCellLocation(levels)
%Input: levels is the level of each discrete parameter
%output: is all possibile pair-wise combination of discrete parameter
%find all pair-wise discrete data (1,1) (1,2),...; (2,1),(2,2)...
%make a multi dimension matrix for n discrete variables i.e. 4 discrete variable
%each has 2 level M=2x2x2x2 matrix

%make cell location matrix
str='i=1;';
str2='';
str3='i=i+1;';
kl=length(levels);
for i=1:kl
   str=[str,'for i',num2str(i),' =1:',num2str(levels(i)),';' ];
   str2=[str2,'i',num2str(i),' '];
   str3=[str3,'end;'];
end
str=[str,'cell_location(i,:)=[',str2,'];',str3 ];
eval(str);
%cell_location

%below version sometimes not work, a small bug 
%str=['combvec('];
%str1=[];
%kl=length(levels);
%for i=1:kl
%	%assignin('base',['a',num2str(i)],1:levels(i));
%	%str1=[str1,['a',num2str(i)]];
%	str1=[str1,num2str(1),':',num2str(levels(i))];
%	if i<kl
%		str1=[str1,','];
%	end
%end
%str=[str,str1,')'];
%cell_location=evalin('base',str);
%cell_location=cell_location';
%cell_location= fliplr(cell_location')





