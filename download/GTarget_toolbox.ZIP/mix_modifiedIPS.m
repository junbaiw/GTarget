function [out_data,LL,Deviance]=mix_modifiedIPS(all_data,all_moments,out_data, cell_location, ia, out_cellIndex,convergens,isdebuge)
%Input: out_data is initial values for all parameters
%ia is the number of submodel, out_cellIndex contains the index of each
%submodel
%Note, is full discrete model with  partial continues model then set 1 in
%covariance matrix i.e. ABX,ABY
%if partial discrete model with partial continues model then set global
%variance in covariance matrix i.e. AX, BY
%Note the observer variable seems need compute manuall according to
%different models!!!
%
global old_out_data
istype=out_cellIndex.istype;
remove_edges=out_cellIndex.remove_edges;
cell_idx=out_cellIndex.cell_idx;
sub_model_level=out_cellIndex.sub_model_level;
nij=all_moments.nij;
uij=all_moments.uij;
Tij=all_data.Tij;
Sij=all_data.Sij;
sigmaij=all_moments.sigmaij;
obs_pij=all_moments.obs_pij;
obs_uij=all_moments.obs_uij;
obs_sigmaij=all_moments.obs_sigmaij;

N=all_moments.N;
q=all_moments.q;

continues_data=all_data.continues_data;
discrete_data=all_data.discrete_data;
Ls=all_data.Ls;

new_out_data={};
num_dist=1;
new_out_data=cell(size(out_data)); 
max_parm_diff=100;
cycle=1;
temp_parm_diff=[];
fitted_pij=all_data.fitted_pij;
fitted_uij=all_data.fitted_uij;
fitted_sigmaij=all_data.fitted_sigmaij;
new_out_data=out_data;

%while max_parm_diff>convergens
while 1
  level_count=1;
   for i=1:ia
        %loop in submodels
        cycle;
        %this example is testing model A,B/AX,AY,BX,BY/AXY,BXY by delteing
        %edge AB
    	%loop in ia: marginal count to descrite variable ia
        for j=1:sub_model_level(i)
        %loop in sublevel of each ia
        clear obs_alpha obs_beta obs_omega fitted_alpha fitted_beta fitted_omega delta_alpha delta_beta delta_omega
        clear temp_cell temp_cell_idx
            current_ia=i;
            current_ia_level=j;
            temp_cell=cell_idx{i};
            if iscell(temp_cell)
                temp_cell_idx=temp_cell{current_ia_level};
            else
                temp_cell_idx=temp_cell(current_ia_level);
            end
            
 	    clear current_alpha current_beta current_omega
            current_alpha={out_data{temp_cell_idx,1}};
            current_beta={out_data{temp_cell_idx,2}};
            current_omega={out_data{temp_cell_idx,3}};
            [row,col]=size(current_alpha);
            
	    %compute observered parameters
            clear p_ia u_ia sigma_ia
            p_ia=nij(temp_cell_idx)./N;
            u_ia=uij(temp_cell_idx,:);
            sigma_ia=cell(col,1);
            sigma_ia(1:col)={sigmaij{temp_cell_idx}};

            if (istype(i)==2 ) 
                %if have continues variable be removed with full discrete
                %correct model
                 t_remove_variable=remove_edges{i}; 
                 for gii=1:length(t_remove_variable)
                        	u_ia(:,t_remove_variable(gii))=mean(continues_data(:,t_remove_variable(gii)));
                 end
                t_sigma_ia=sigma_ia{1}; %at here we assume only one sigma in cell!!
                for gi=1:size(t_sigma_ia,1)
                    for gj=1:size(t_sigma_ia,2)
                        if (~isempty(intersect([gi,gj],t_remove_variable)) & (gi~=gj))
                            t_sigma_ia(gi,gj)=0;
                        end 
                    end
                end
               	for gii=1:length(t_remove_variable)
                      	t_sigma_ia(t_remove_variable(gii),t_remove_variable(gii))=1; %mix_compute_sigma(continues_data(:,t_remove_variable(gii)));
                end
                sigma_ia{1}=t_sigma_ia;
            end
             
            if istype(i)==3
                %both continues and discrete model are partial
                %not correct
                t_remove_variable=remove_edges{i};
                remain_variable=setdiff(1:q,t_remove_variable);
                
		%replace removed continues with global mean
                for gii=1:length(t_remove_variable)
                        	u_ia(:,t_remove_variable(gii))=mean(continues_data(:,t_remove_variable(gii)));
                end
                
                len_of_sigma=length(sigma_ia);
                for jj=1:len_of_sigma
                    t_sigma_ia=sigma_ia{jj}; %at here we assume only one sigma in cell!!
                    for gi=1:size(t_sigma_ia,1)
                        for gj=1:size(t_sigma_ia,2)
                            if (~isempty(intersect([gi,gj],t_remove_variable)) & (gi~=gj))
                                t_sigma_ia(gi,gj)=0;   %set zero at removed continues edges
                            end 
                        end
                    end
                   
                    for gii=1:length(t_remove_variable)
                       	t_sigma_ia(t_remove_variable(gii),t_remove_variable(gii))=1; %mix_compute_sigma(continues_data(:,t_remove_variable(gii)));
                    end
                   
                    sigma_ia{jj}=t_sigma_ia;
                end %end jj
             end
 	
	    %if istype(i)==1           
                %full continues model with deleted discrete variables
	    %end
	    %if istype(i)==4
		%Full model
            %end

            [obs_alpha,obs_beta, obs_omega,iszero1,obs_n,obs_u,obs_sigma]=mix_observed_moment2canonical_new(p_ia,u_ia,sigma_ia,q,N,0);
            
	    %compute fitted parameters by current marginal counts in out_data
            clear current_m_ia current_u_ia current_sigma_ia
            current_m_ia=[out_data{temp_cell_idx,4}];
            current_u_ia={out_data{temp_cell_idx,5}};
            current_sigma_ia={out_data{temp_cell_idx,6}};
            [fitted_alpha, fitted_beta, fitted_omega,iszero2,fitted_n,fitted_u,fitted_sigma]=mix_fitted_moment2canonical(...
                N,q,current_m_ia,current_sigma_ia,current_u_ia,0);
            
	    %compute moment difference
            if (istype(i)==2 | istype(i)==3) 
                for gii=1:length(t_remove_variable)
	        	obs_u(t_remove_variable(gii))=0;
                	fitted_u(t_remove_variable(gii))=0;
		        obs_sigma(t_remove_variable(gii),t_remove_variable(gii))=1;
                        fitted_sigma(t_remove_variable(gii),t_remove_variable(gii))=1;
		end
                for gi=1:size(obs_sigma,1)
                    for gj=1:size(obs_sigma,2)
                        if (~isempty(intersect([gi,gj],t_remove_variable)) & (gi~=gj))
                            obs_sigma(gi,gj)=0;        %set zero in removed continues edges 
                            fitted_sigma(gi,gj)=0;
                        end
                    end
                end
            end
            delta_m_ia=abs(obs_n-fitted_n);
            delta_u_ia=max(max(abs(obs_u-fitted_u)));
            delta_sigma_ia=max(max(abs(obs_sigma-fitted_sigma)));
            max_parm_diff=max([delta_m_ia,delta_u_ia,delta_sigma_ia]);
            
            if max_parm_diff>=convergens
		 [obs_alpha, obs_beta, obs_omega]=mix_moment2canonical_new(obs_n./N,obs_u,obs_sigma,q);
		 [fitted_alpha,fitted_beta,fitted_omega]=mix_moment2canonical_new(fitted_n./N,fitted_u,fitted_sigma,q);
			
                %if maximu moment > congervens then updata alpha, beta, omega here temporily set gema_n=1 !! Later
                %have to change it!! And check positive matrix use step halve
                gema_n=1;
            
                %compute canconical paremeter difference
                delta_alpha=(obs_alpha-fitted_alpha);
                delta_beta=(obs_beta-fitted_beta);
                delta_omega=(obs_omega-fitted_omega);
                clear new_alpha  new_beta new_omega temp_parm_diff
                for nl=1:col
                    new_alpha{nl}=current_alpha{nl}+gema_n*delta_alpha;
                    new_beta{nl}=current_beta{nl}+gema_n*delta_beta;
                    new_omega{nl}=current_omega{nl}+gema_n*delta_omega;
                end
                temp_parm_diff{j}={abs(delta_alpha),abs(delta_beta),abs(delta_omega)};    
                %update parameter in output
                new_out_data(temp_cell_idx,1)=new_alpha;
                new_out_data(temp_cell_idx,2)=new_beta;
                new_out_data(temp_cell_idx,3)=new_omega;
                [new_p, new_u, new_sigma]=mix_canonical2monent(new_alpha,new_beta, new_omega,q);
            
                clear new_m_ia  matrix_new_m_ia		
                for nl=1:col	    
                    new_m_ia{nl}=new_p{nl}.*N;
                    matrix_new_m_ia(nl)=new_p{nl}.*N;
                end
                new_out_data(temp_cell_idx,4)=new_m_ia;
                new_out_data(temp_cell_idx,5)=new_u;
                new_out_data(temp_cell_idx,6)=new_sigma;
           
                temp_pij=matrix_new_m_ia./N;
                fitted_pij(temp_cell_idx)=temp_pij;
                fitted_uij(temp_cell_idx)=new_u;
                fitted_sigmaij(temp_cell_idx)=new_sigma;
            end %end if update
        end %end j
        if max_parm_diff>=convergens
	 	old_out_data=out_data;
        	if isdebuge==1
			out_data=new_out_data
		else
			out_data=new_out_data;
		end

	end

 	%maximum moment difference between updated parameters 
        %max_parm_diff
	if  max_parm_diff<convergens
		is_true(i)=1;
	else
		is_true(i)=0;
	end

	if max_parm_diff>=convergens 	
		%maximum canonical difference between updated parameters
		len_diff=length(temp_parm_diff);
        	temp_max_parm_diff=0.000;
        	for nd=1:len_diff
            		temp_pd=temp_parm_diff{nd};
            		len_pd=length(temp_pd);
            		for ndd=1:len_pd
                		temp_pdd=max(max(temp_pd{ndd}));
                		if temp_pdd>temp_max_parm_diff
                    			temp_max_parm_diff=temp_pdd;
                		end
            		end
       		end
        	max_canonical_parm_diff=temp_max_parm_diff;
 
        	%fitted model likelihood
        	Lm=mix_likelihood_fittedModel_new(N,obs_pij,obs_uij,obs_sigmaij,q,fitted_pij,fitted_uij,fitted_sigmaij);
        	if isdebuge==1
	  		LL=Lm*(-2)
        		Deviance=abs(-2*(Ls-Lm))
		else
	 		LL=Lm*(-2);
                	Deviance=abs(-2*(Ls-Lm));
		end
	end

        cycle=cycle+1;
        %pause
    end %end i
	%is_true,cycle
	if sum(sum(is_true))/ia==1
		break
	end
end %end while

