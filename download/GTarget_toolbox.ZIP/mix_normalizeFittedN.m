function [new_out_data,fitted_pij]=mix_normalizeFittedN(new_out_data,N,q,fitted_pij)
%normzlize fitted n, otherwise, it makes algorithm hard to converge!
    
%digits(64);
sum_n=sum([new_out_data{1:end,4}]);
if sum_n~=N
                new_n=[new_out_data{1:end,4}]./sum_n.*N;
                have_n=[];
                idx_n=1;
                for ik=1:length(new_n)
                    new_out_data{ik,4}=new_n(ik);
                    if new_n(ik)>2.9E-38
                        have_n(idx_n)=ik;
                        idx_n=idx_n+1;
                    end
                    fitted_pij(ik)=new_n(ik)/N;
                end
                for ik=1:length(have_n)
                    [alpha, beta, omega]=mix_moment2canonical_new2(new_out_data{have_n(ik),4},...
                        new_out_data{have_n(ik),5},new_out_data{have_n(ik),6},q,N);
                    new_out_data{have_n(ik),1}=alpha;
                    new_out_data{have_n(ik),2}=beta;
                    new_out_data{have_n(ik),3}=omega;            
                end
end
%normalization of fitted n is important otherwise the algorm will not converge!! Oct 20. 2005
%end normalize
            