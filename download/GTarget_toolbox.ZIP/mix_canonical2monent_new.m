function [n, u, sigma]=mix_canonical2monent_new(alpha, beta, omega,q,N)
%Input canonical parameter, q is the number of continues variables
%alpha ,beta and omega is cell
%Output moment parameter, n,u,sigma
%
%digits(64);
[row, col]=size(alpha);
sigma=cell(row,col);
u=cell(row,col);
n=cell(row,col);

for i=1:col
    %omega{i}
    %i
    %if isempty( find(isnan(omega{i})==1) )| isempty( find(isinf(omega{i})==1) )
        tt_omega=omega{i};
        tt_omega(find(isnan(tt_omega)))=0;
        sigma(i)={pinv(tt_omega)};
    %else   
    %    omega{i},alpha{i}, beta{i}, q,N
    %    break;
    %end
	u(i)={sigma{i}*beta{i}};
	part_a=det(omega{i});
   
    if det(sigma{i})<=0 %2.9E-38 %3.7201e-44 %2.9E-38
        n(i)={0};
        u(i)={zeros(size(u{i}))};
        sigma(i)={zeros(size(sigma{i}))};
    else
        if part_a<=0 %2.9E-38 %3.7201e-44  %2.9E-38
            log_n=0;
            u(i)={zeros(size(u{i}))};
            sigma(i)={zeros(size(sigma{i}))};
        else
            log_n=q/2.*log(2*pi)-1./2.*log(part_a)+(alpha{i}+1/2.*beta{i}'*sigma{i}*beta{i})+log(N);
            if log_n<-88.02886
                log_n=0;
            else
                if log_n>88.02886 %100 %88.02886
                    log_n=1.7E+38; %2.6881e+043; %1.7E+38;
                else
                    log_n=exp(log_n);
                end
            end
        end 
        n(i)={log_n};
        %p(i)={(2*pi).^(q/2).*(part_a).^(-1/2).*exp(alpha{i}+1/2.*beta{i}'*sigma{i}*beta{i})};
      end
end

