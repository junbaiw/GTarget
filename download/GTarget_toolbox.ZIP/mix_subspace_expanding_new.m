function [all_dimMF,len_dimMF,record_all_dimMF_sign,record_all_dimMF_coef,dim]=mix_subspace_expanding_new(all_dimMF,full_discrete,full_discrete_sublevel,full_continues)
%start recurisively expanding the sets D(A,B)=D(A)+D(B)-D(A^B)
idx=1;
len_dimMF=length(all_dimMF);
new_all_dimMF=cell(1,len_dimMF);
new_record_all_dimMF_sign=[];
new_all_dimMF_coef=[];
record_all_dimMF_sign=0;
record_all_dimMF_coef=1;
dim=0;

while 1
	for i=1:len_dimMF
		temp_dimMF=all_dimMF{i};
		len_of_temp_dimMF=length(temp_dimMF);
		record_dimMF_length(i)=len_of_temp_dimMF;
		if len_of_temp_dimMF>1
			%try to expand if it is single set then compute dim otherwise store in new
            		%sets
            		%t_sign=xor(record_all_dimMF_sign(i),0);
            		%t_dimMF={temp_dimMF{end}};
            		%t_dim=mix_compute_degree_of_freedom(t_dimMF,1,t_sign,...
            		%full_discrete,full_discrete_sublevel,full_continues); 
            		%dim=dim+t_dim;
            		new_all_dimMF{idx}={temp_dimMF{end}};
            		new_record_all_dimMF_sign(idx)=xor(record_all_dimMF_sign(i),0); %1 is -, 0 is +
			new_record_all_dimMF_coef(idx)=1*  record_all_dimMF_coef(i);
            		new_record_dimMF_length(idx)=1;
            		idx=idx+1;
            
			new_all_dimMF{idx}={temp_dimMF{1:end-1}};
			new_record_all_dimMF_sign(idx)=xor(record_all_dimMF_sign(i),0);
            		new_record_all_dimMF_coef(idx)=1*  record_all_dimMF_coef(i);
            		new_record_dimMF_length(idx)=length(temp_dimMF)-1;
			idx=idx+1;
			len_of_sub_temp=length(temp_dimMF)-1;
			temp_sub_model={};
            		%start to make intersecttion of two sets
			for j=1:len_of_sub_temp
                		sub_c=intersect(temp_dimMF{j},temp_dimMF{end});
                		sub_intersect=[];
                		for jj=1:length(sub_c)
                    			sub_temp_dimMF=strvcat(temp_dimMF{j});
                    			sub_str_idx=findstr(strvcat(sub_c(jj)),sub_temp_dimMF);
                                	end_sub_str_idx=findstr(strvcat(sub_c(jj)),temp_dimMF{end});
                                	if length(end_sub_str_idx)==length(sub_str_idx)
                    				sub_intersect=[sub_intersect,strvcat(sub_temp_dimMF(sub_str_idx))];
                                	else
                                    		num_of_sub_str=min(length(end_sub_str_idx),length(sub_str_idx));
                                    		sub_intersect=[sub_intersect,strvcat(sub_temp_dimMF(sub_str_idx(1:num_of_sub_str)))];
                                	end
                		end
                		if isempty(sub_intersect)
                    			temp_sub_model{j}='_';
                		else
                    			temp_sub_model{j}=sub_intersect;
                		end
			end	        	
			new_all_dimMF{idx}=temp_sub_model;
			new_record_all_dimMF_sign(idx)=xor(record_all_dimMF_sign(i),1);
            		new_record_all_dimMF_coef(idx)=1* record_all_dimMF_coef(i);
            		new_record_dimMF_length(idx)=length(temp_sub_model);
			idx=idx+1;
		else
				new_all_dimMF{idx}=all_dimMF{i};
				new_record_all_dimMF_sign(idx)=record_all_dimMF_sign(i);
                		new_record_all_dimMF_coef(idx)=record_all_dimMF_coef(i);
                		new_record_dimMF_length(idx)=record_dimMF_length(i);
				idx=idx+1;
            		
            		%if it is single set then compute it's dim and do not include
            		%it in further calculation
            		%t_sign=record_all_dimMF_sign(i);
            		%t_dimMF=all_dimMF{i};
            		%t_dim=mix_compute_degree_of_freedom(t_dimMF,1,t_sign,...
                	%full_discrete,full_discrete_sublevel,full_continues); 
            		%dim=dim+t_dim;
        	end %end if
    	end %end for

  %added wang 2005
  %try to find identical sets for example '_' and remove them then updated the coffe of its related sets
  %first find all single cell sets
  single_cell_idx=find(new_record_dimMF_length==1);
  if (~isempty(single_cell_idx) & length(single_cell_idx)>1)
        %define all single sets
	temp_old_all_dimMF=[new_all_dimMF{single_cell_idx}];
	temp_old_all_dimMF_sign=new_record_all_dimMF_sign(single_cell_idx);
	temp_old_all_dimMF_coef=new_record_all_dimMF_coef(single_cell_idx);
	temp_old_record_dimMF_length=new_record_dimMF_length(single_cell_idx);
       	%try to find the identical subsets
       	[uniq_temp_old_all_dimMF,uniq_idx]=unique(temp_old_all_dimMF);
       	%pause
       	%[temp_find,temp_find_Idx]=intersect(temp_old_all_dimMF,uniq_new_all_dimMF);
       	if length(uniq_temp_old_all_dimMF)<length(temp_old_all_dimMF)
	     	%first get all nonone single sets	
	     	temp_all_idx=1:length(new_all_dimMF);
	     	temp_new_all_idx=setdiff(temp_all_idx,single_cell_idx);
	     	temp_new_all_dimMF=new_all_dimMF(temp_new_all_idx);
		% temp_new_all_dimMF{1:end}
	     	temp_new_all_dimMF_sign=new_record_all_dimMF_sign(temp_new_all_idx);
	     	temp_new_all_dimMF_coef=new_record_all_dimMF_coef(temp_new_all_idx);
	     	temp_record_dimMF_length=new_record_dimMF_length(temp_new_all_idx);
                [temp_new_all_dimMF, temp_new_all_dimMF_sign,temp_new_all_dimMF_coef,temp_record_dimMF_length]=mix_remove_identical_cell(...
			temp_new_all_dimMF, temp_new_all_dimMF_sign,temp_new_all_dimMF_coef,temp_record_dimMF_length);
		%temp_new_all_dimMF{1:end}, temp_new_all_dimMF_sign,temp_new_all_dimMF_coef,temp_record_dimMF_length
		%pause
                
	     	%then keep all uniq single sets (both sign) and update its coeff and remove the rest one	
       	       	ed_dimMF=length(temp_new_all_dimMF_coef);
               	gii_idx=1;
               	for gii=1:length(uniq_idx)
                    	coef_idx=[];
                    	coef_idx=strmatch(temp_old_all_dimMF(uniq_idx(gii)),temp_old_all_dimMF,'rows');
                    	if length(coef_idx)==1
                        	temp_new_all_dimMF(ed_dimMF+gii_idx)={temp_old_all_dimMF(coef_idx)};
                        	temp_new_all_dimMF_sign(ed_dimMF+gii_idx)=temp_old_all_dimMF_sign(coef_idx);    
                        	temp_record_dimMF_length(ed_dimMF+gii_idx)=temp_old_record_dimMF_length(coef_idx);
                       		temp_new_all_dimMF_coef(ed_dimMF+gii_idx)=temp_old_all_dimMF_coef(coef_idx);
                        	gii_idx=gii_idx+1;
                    	else
                        	temp_sign=temp_old_all_dimMF_sign(coef_idx);
                        	temp_coef=temp_old_all_dimMF_coef(coef_idx);
                        	one_idx=find(temp_sign==1);
                        	zero_idx=find(temp_sign==0);
                        	if ~isempty(one_idx) & ~isempty(zero_idx)
                            		delta_coef=(sum(temp_coef(one_idx))-sum(temp_coef(zero_idx)));
                            		if delta_coef>0
                                		temp_new_all_dimMF(ed_dimMF+gii_idx)={temp_old_all_dimMF(coef_idx(1))};
                                		temp_new_all_dimMF_coef(ed_dimMF+gii_idx)=abs(delta_coef); 
                                		temp_record_dimMF_length(ed_dimMF+gii_idx)=temp_old_record_dimMF_length(coef_idx(1));
                                		temp_new_all_dimMF_sign(ed_dimMF+gii_idx)=1;
                                		gii_idx=gii_idx+1;
                            		elseif delta_coef<0
                                		temp_new_all_dimMF(ed_dimMF+gii_idx)={temp_old_all_dimMF(coef_idx(1))};
                                		temp_new_all_dimMF_coef(ed_dimMF+gii_idx)=abs(delta_coef); 
                                		temp_record_dimMF_length(ed_dimMF+gii_idx)=temp_old_record_dimMF_length(coef_idx(1));
                                		temp_new_all_dimMF_sign(ed_dimMF+gii_idx)=0;
                                		gii_idx=gii_idx+1;
                            		end
                        	elseif ~isempty(one_idx) & isempty(zero_idx)
                            		delta_coef=sum(temp_coef(one_idx));
                            		temp_new_all_dimMF(ed_dimMF+gii_idx)={temp_old_all_dimMF(coef_idx(1))};
                            		temp_new_all_dimMF_coef(ed_dimMF+gii_idx)=abs(delta_coef); 
                            		temp_record_dimMF_length(ed_dimMF+gii_idx)=temp_old_record_dimMF_length(coef_idx(1));
                            		temp_new_all_dimMF_sign(ed_dimMF+gii_idx)=1;
                            		gii_idx=gii_idx+1;
                       		 elseif isempty(one_idx) & ~isempty(zero_idx)
                            		delta_coef=sum(temp_coef(zero_idx));
                            		temp_new_all_dimMF(ed_dimMF+gii_idx)={temp_old_all_dimMF(coef_idx(1))};
                            		temp_new_all_dimMF_coef(ed_dimMF+gii_idx)=abs(delta_coef); 
                            		temp_record_dimMF_length(ed_dimMF+gii_idx)=temp_old_record_dimMF_length(coef_idx(1));
                            		temp_new_all_dimMF_sign(ed_dimMF+gii_idx)=0;
                            		gii_idx=gii_idx+1;
                        	 end %end if
                    		end %end if
                	end %end for unique sets
	else
	     		temp_new_all_dimMF=new_all_dimMF;
            		temp_new_all_dimMF_sign=new_record_all_dimMF_sign;
            		temp_new_all_dimMF_coef=new_record_all_dimMF_coef;
            		temp_record_dimMF_length=new_record_dimMF_length;
        end %end if temp_find
     else
        %did not find identical sets
	temp_new_all_dimMF=new_all_dimMF;
       	temp_new_all_dimMF_sign=new_record_all_dimMF_sign;
       	temp_new_all_dimMF_coef=new_record_all_dimMF_coef;
       	temp_record_dimMF_length=new_record_dimMF_length;
    end %end if single ccell

    
    
    all_dimMF=temp_new_all_dimMF;
    %all_dimMF{1:end}
    record_all_dimMF_sign=temp_new_all_dimMF_sign;
    record_all_dimMF_coef=temp_new_all_dimMF_coef;
    record_dimMF_length=temp_record_dimMF_length;
	%pause
    
	len_dimMF=length(record_all_dimMF_sign);
    	sum(sum(record_dimMF_length))/length(record_dimMF_length);
	new_all_dimMF=cell(1,len_dimMF);
	new_record_all_dimMF_sign=[];
	new_record_all_dimMF_coef=[];
    	new_record_dimMF_length=[];
	idx=1;

	if sum(sum(record_dimMF_length))/length(record_dimMF_length)==1
		break;
	end
end %end while

