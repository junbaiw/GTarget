function out_model=mix_delete_singleDiscrete(t_model)
%remove single discrete variable from model
%all_discrete is the maximum full model of discrete variables
%current the maximum number discrete variable is 52 
all_discrete='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

len_of_model=length(t_model);
idx=0;
record_idx=[];
for i=1:len_of_model
    if length(t_model{i})==1 & sum(ismember(t_model{i},all_discrete))==1
    %remove this single discrete variable from model
        idx=idx+1;
        record_idx(idx)=i;
    end
end
new_idx=setdiff(1:len_of_model,record_idx);
out_model=cell(size(new_idx));
out_model(1:end)=t_model(new_idx);
