% GTarget Toolbox
% Version 1.0beta, July. 2 2006
% 
% Copyright 2004-2006 by
% Junbai Wang
% Contributed files may contain copyrights of their own.
% 
% GTarget Toolbox comes with ABSOLUTELY NO WARRANTY; for details
% see License.txt in the program package. This is free software,
% and you are welcome to redistribute it under certain conditions;
% see License.txt for details.
% 
% 
% GTarget
% 
%        gtarget_toolbox   this file
%        License.txt   GNU General Public License 
%        Copyright.txt   Copyright notice
