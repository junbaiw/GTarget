function fid=export2cytoscape_graph(filename,g_r,g_c,vars,cases,isclose,fid)
%filename='export_to_cytoscape.csv'
if isempty(fid)
	fid=fopen(filename,'W');
end
for i=1:length(g_r)
        col_name=deblank(cases(g_r(i),:));
        row_name=deblank(vars(g_c(i),:));
        fprintf(fid,'%s %s %s %s %s\n',strvcat(row_name),' ','pp',' ', ...
                strvcat(col_name));
end

%fid=fopen(filename,'W');
%for i=1:length(g_r)
%        row_name=new_vars2(g_r(i));
%        col_name=new_cases2(g_c(i));
%        fprintf(fid,'%s%s%s%s%s\n',strvcat(row_name),' ','pp',' ',strvcat(col_name));
%end
if isclose
	fclose(fid);
end

