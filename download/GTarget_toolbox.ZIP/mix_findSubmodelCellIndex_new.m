function out_cellIndex=mix_findSubmodelCellIndex_new(cell_location,fullmodel_discrete,fullmodel_continues,submodel,len_submodel,discrete_levels)
%Input: full_discrete, full_continues, submodel, len_submodel,
%discrete_level
%Output: out_cellIndex.istype, .cellIdx, .remove_edges, .sub_model_level
%
    ia=len_submodel;
    %make cell idx for each submodel
    for i=1:ia
        %loop in all submodels
        temp_model=[]; 
        str_of_continues=[]; removeStr_of_continues=[];
        re_IA=[]; re_IB=[];IA=[];IB=[];
        str_of_discretes=[]; removeStr_of_discretes=[];
        re_IdA=[]; re_IdB=[]; IdA=[];IdB=[];
        
        temp_model=submodel{i};
    
	    [str_of_continues, IA, IB] =intersect(temp_model,fullmodel_continues{1});
        [removeStr_of_continues,re_IA]=setdiff(fullmodel_continues{1},temp_model);
        
        [str_of_discretes, IdA, IdB]=intersect(temp_model,fullmodel_discrete{1});
        [removeStr_of_discretes,re_IdA]=setdiff(fullmodel_discrete{1},temp_model);
        len_of_continues=length(str_of_continues);
        len_of_discretes=length(str_of_discretes);
        
        if len_of_continues==length(fullmodel_continues{1});
            %check whether have continues variable be removed
            is_miss_continues=1; %full continues
        else
            is_miss_continues=0;
        end
        if len_of_discretes==length(fullmodel_discrete{1})
            %check whether have discrete variable be removed
            is_miss_discrete=1; %full discretes
        else
            is_miss_discrete=0;
        end
        
        % [is_miss_continues,is_miss_discrete]
        %pause
        %start find cell index based on different submodels
        if is_miss_continues==1 & is_miss_discrete==0
            %full continues model with deleted discrete variables
            len_of_marginalDis=length(IdB);
            t_cell_idx={};
            temp_cell=[];
            temp_cell=cell_location(:,IdB);
            uniq_cell=unique(temp_cell,'rows');
            len_of_uniq_cell=size(uniq_cell,1);
            %pause
            for k=1:len_of_uniq_cell
                temp_cell_idx=[];
                temp_cell_idx=find(sum(abs(temp_cell-repmat(uniq_cell(k,:),size(temp_cell,1),1)),2)==0);
                t_cell_idx{k}=temp_cell_idx;
            end
            if isempty(t_cell_idx)
            	%no discrete variables, it may homongenous model
                len_of_conVar=size(cell_location,1);
                cell_idx{i}={[1:len_of_conVar]'};%temp_cell_idx;
            else
            	cell_idx{i}=t_cell_idx;
            end
            sub_model_level(i)=len_of_uniq_cell ; 
            remove_edges{i}=0;
            istype(i)=1; % 1 means delete discrete variable full continues model 
        elseif is_miss_continues==0 & is_miss_discrete==1
            %full discrete model with deleted continues variables
            %BUG current only support remove 1 continues variable at once!
             len_of_marginalCon=length(re_IA);
             num_of_cell=size(cell_location,1); %all pair-wise discrete cell counts
             cell_idx{i}=1:num_of_cell;
             sub_model_level(i)=num_of_cell;
             remove_edges{i}=re_IA;
             istype(i)=2; %2 means delete continues variables full discrete model
        elseif is_miss_continues==1 & is_miss_discrete==1
            %BUG not finish yet, it is full model
            %disp('Full model !!');
            istype(i)=4;
            remove_edges{i}=0;
	        num_of_cell=size(cell_location,1); %all pair-wise discrete cell counts
            cell_idx{i}=1:num_of_cell;
            sub_model_level(i)=num_of_cell;
        elseif is_miss_continues==0 & is_miss_discrete==0
            %BUG, not finish yet !! partial discrete and partial continues model
            %disp('Both discrete and continues model is not full!');
            t_cell_idx={};
            temp_cell=[];
            temp_cell=cell_location(:,IdB);
            uniq_cell=unique(temp_cell,'rows');
            len_of_uniq_cell=size(uniq_cell,1);
            for k=1:len_of_uniq_cell
                temp_cell_idx=[];
                temp_cell_idx=find(sum(abs(temp_cell-repmat(uniq_cell(k,:),size(temp_cell,1),1)),2)==0);
                t_cell_idx{k}=temp_cell_idx;
            end
            %t_cell_idx
            %pause
            if isempty(t_cell_idx)
                %no discrete variables, it may homongenous model
                %len_of_conVar=size(cell_location,1);
                %cell_idx{i}=1:len_of_conVar;%temp_cell_idx;
                %sub_model_level(i)=len_of_conVar;
                len_of_conVar=size(cell_location,1);
                cell_idx{i}={[1:len_of_conVar]'};
                sub_model_level(i)=len_of_uniq_cell;
            elseif (length(t_cell_idx)==1 & length(t_cell_idx{1})==size(cell_location,1) )
                len_of_conVar=size(cell_location,1);
                cell_idx{i}={[1:len_of_conVar]'};
                sub_model_level(i)=len_of_uniq_cell;
                %this may homongenous model
                %len_of_conVar=size(cell_location,1);
                %cell_idx{i}=1:len_of_conVar;%temp_cell_idx;
                %sub_model_level(i)=len_of_conVar;
            else
                cell_idx{i}=t_cell_idx;
                sub_model_level(i)=len_of_uniq_cell;
            end
           
 	        remove_edges{i}=re_IA;           
       	    istype(i)=3;
        end
    end
    out_cellIndex.istype=istype;
    out_cellIndex.remove_edges=remove_edges;
    out_cellIndex.sub_model_level=sub_model_level;
    out_cellIndex.cell_idx=cell_idx;
