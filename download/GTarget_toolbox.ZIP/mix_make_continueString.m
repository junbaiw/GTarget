function stringVector=mix_make_continueString(numberVector)
%input number of edge location
%output corresponding the string name for example
%current only have 10 discrete variables
%Input [ 1 2; 2 3]
%Output {a b; b c}
[r c]=size(numberVector);
if max([r c])<37
   for i=1:r
      tempNum=numberVector(i,:);
      tempString=[];
      for j=1:length(tempNum)
	    if j<=10
             tempString=strcat(tempString,char(47+tempNum(j)));
 	    else	
             tempString=strcat(tempString,char(64+22+tempNum(j)));
	    end
       end
      stringVector{i}=tempString;
    end
else
  display('Maxim continues variable is 36 ! He Stop!')
  return;
end

