function [obs_n,obs_u,obs_sigma]=mix_observed_HOMmoment_new(...
    t_obs_nia,t_obs_uia,t_obs_sigmaia,q,N,ishom)
%Input S_ia is sum of squares, T_ia is marginal total, N_ia is number of discretes,
%q is the number of contionus variables, N is total count
%obs_u=T_ia./N_ia;
%ishom=1 is homogeneous model
%ishom=0 is heterogeneous model
%
warning off;
idx_good=find(t_obs_nia>2.9E-38); %3.7201e-44);
obs_nia=t_obs_nia(idx_good);
obs_uia=t_obs_uia(idx_good,:);
obs_sigmaia=cell(1,length(idx_good));
obs_sigmaia={t_obs_sigmaia{idx_good}};
%end wang

if ~isempty(idx_good)
    [row col]=size(obs_uia);
    nk=obs_nia;
    obs_n=sum(sum(nk));
    obs_u=reshape((sum(repmat(nk,1,col).*obs_uia,1)./obs_n),col,1);
    obs_u(find(abs(obs_u)==inf))=0;
    obs_u(find(isnan(abs(obs_u))))=0;
    t_ss=zeros(size(obs_sigmaia{1}));
    for i=1:row
        t_ss=t_ss+(nk(i)*(obs_sigmaia{i}+obs_uia(i,:)'*obs_uia(i,:)));    
    end
    %added wanf
    %t_ss/obs_n,obs_u*obs_u'
    obs_sigma=(t_ss/obs_n-obs_u*obs_u');
    %obs_sigma(find(abs(obs_sigma)==inf))=0;
    %obs_sigma(find(isnan(abs(obs_sigma))))=0;
    %end added
    %obs_p=obs_n./N;

    %added wang
    obs_sigma(find(obs_sigma>=0.9999 & obs_sigma<=1.0))=1;
    %obs_p(find(obs_p>=0.9999 & obs_p<=1.0))=1;            
else
    obs_n=0;
    obs_u=zeros(max(size(t_obs_uia(1,:))),1);
    obs_sigma=zeros(size(t_obs_sigmaia{1}));
end
