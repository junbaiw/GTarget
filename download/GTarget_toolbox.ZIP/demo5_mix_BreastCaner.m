function mixHomCoheren_Breast()
clear all
t0 = clock;

%diary;
%
%
%2005
%file1='exp_chip_cycle1_data.csv'
file1='in/breastcancer_mix_input.txt' %'rats_data_mix_input.txt'
num_discrete=4; %2; %9;
num_continues=6; %2; %9;
discrete_col=[7:10]; %[1:2]; %[10:18];
continues_col=[1:6]; %[3:4]; %[1:9];
full_discrete={'ABCD'}; %{'AB'}; %{'ABCDEFGHI'};
full_discrete_sublevel=[2,2,2,2];%[2,3]; %[2,2,2,2,2,2,2,2,2];
full_continues={'012345'}; %{'01'}; %{'012345678'}; %X=0, Y=1
[data,vname,cname]=tblread(file1,'\t');
%finish input data!


%start to build full model
ishom=0;
full_model= mix_make_fullModel(num_discrete,num_continues,ishom);

[row col]=size(data);
xy_col=continues_col;
AB_col=discrete_col;

%find the number of level in each discrete variable
levels=mix_findDiscreteLevels(data,AB_col);
num_of_discrete=length(AB_col);

%find mean of each continues variable
num_of_continues=length(xy_col);
all_mean=mean(data,1);
mean_AB=all_mean(:,xy_col);

%find all pair-wise discrete data (1,1) (1,2),...; (2,1),(2,2)...
%make a multi dimension matrix for n discrete variables i.e. 4 discrete variable
%each has 2 level M=2x2x2x2 matrix
cell_location=mix_findCellLocation(levels);

%discrete data and continues data
discrete_data=data(:,AB_col);
continues_data=data(:,xy_col);
N=size(discrete_data,1);

%find each cell's nij, Tij and Sij -Method 2
%and each cell's n, u, sigma
[nij, Tij, Sij,uij,sigmaij,new_cell_location]=mix_findCellCount_new(cell_location, discrete_data,continues_data,N);
q= num_of_continues;
%Observer statistics
nij;Tij;Sij; uij; sigmaij;

%find initial Sufficient statistics 
[fitted_pij,fitted_uij,fitted_sigmaij,out_data]=mix_assignInitialValues(N,cell_location,num_of_continues,num_of_discrete,levels,nij,mean_AB);

%Show all parameters in out_data, column 1 is alpha, 2 is beta, 3 is omega, 4 is mij, 5
%is uij, 6 is sigmaij; each row is (ia(i),ia(j))
out_data;
%likelihood of full model

Ls=mix_likelihood_fullModel_new(N,nij,q,uij,sigmaij);
LL=-Ls*2;
full_model;
dim2=mix_degree_of_freedom_new2(full_discrete,full_discrete_sublevel,full_continues,full_model);
delete_edgeStr='';
mix_printView(full_model, LL, 0, dim2,0,0,'')
full_model_Ls=Ls;
full_model_dim=dim2;
%pause


%fitted likelihood for initial model
obs_pij=nij./N;
obs_uij=uij;
obs_sigmaij=sigmaij;
Lm=mix_likelihood_fittedModel_new(N,obs_pij,obs_uij,obs_sigmaij,q,fitted_pij,fitted_uij,fitted_sigmaij);

%Build inputdata for MDIPS algorithm
all_moments.nij=nij;
all_moments.uij=uij;
all_moments.sigmaij=sigmaij;
all_moments.N=N;
all_moments.q=q;
all_moments.obs_pij=obs_pij;
all_moments.obs_uij=obs_uij;
all_moments.obs_sigmaij=obs_sigmaij;
all_data.fitted_pij=fitted_pij;
all_data.fitted_uij=fitted_uij;
all_data.fitted_sigmaij=fitted_sigmaij;
all_data.continues_data=continues_data;
all_data.discrete_data=discrete_data;
all_data.Ls=Ls;
all_data.Tij=Tij;
all_data.Sij=Sij;
all_data.Ls=Ls;
%finish inital calculation

%compute homongues Full model
ishom=1;
full_model_hom= mix_make_fullModel(num_discrete,num_continues,ishom);

%remove redundant submodels
generate_class=mix_make_model_subspace_new(full_discrete,...
        		full_discrete_sublevel,full_continues,full_model_hom);
%here make model subspace need improve!!

%make a list of all submodels
hom_submodel={};
idx=0;
field_name=fieldnames(generate_class);

if ismember('g',field_name)
    if ~isempty(generate_class.g)
        idx=1;
        for i=1:length(generate_class.g)
            hom_submodel{idx}=generate_class.g{i};
            idx=idx+1;
        end
    end
end

if ismember('h',field_name)
    if ~isempty(generate_class.h)
        if idx>0
            idx=idx;
        else
            idx=1;
        end
        for i=1:length(generate_class.h)
            hom_submodel{idx}=generate_class.h{i};
            idx=idx+1;
        end
    end
end

if ismember('k',field_name)
    if ~isempty(generate_class.k)
        if idx>0
            idx=idx;
        else
            idx=1;
        end
        for i=1:length(generate_class.k)
            hom_submodel{idx}=generate_class.k{i};
            idx=idx+1;
        end
    end
end

convergens=0.00001;
hom_len_submodel=length(hom_submodel);
hom_out_data=out_data;
global old_out_data
isdebuge=0;
hom_out_cellIndex=mix_findSubmodelCellIndex_new(cell_location, full_discrete,...
                full_continues,hom_submodel,hom_len_submodel,full_discrete_sublevel);
[full_out_data,LL,full_Deviance]=mix_modifiedIPS_homogeneous(all_data,all_moments,...
            hom_out_data, cell_location, hom_len_submodel, hom_out_cellIndex,convergens,isdebuge);
%LL
%full_Deviance
all_data.Ls=-LL/2;
P_cutoff=0.05;
dim3=mix_degree_of_freedom_new2(full_discrete,full_discrete_sublevel,full_continues,full_model_hom);
P=Chisq(full_Deviance,dim2-dim3);
mix_printView(full_model_hom, LL,full_Deviance , dim2-dim3,P,P_cutoff,'')
full_hom_model_Ls=-LL/2;
full_hom_model_dim=dim2;
%pause

%start to build all possibile pair-wise edges!
total_nodes=[strvcat(full_discrete),strvcat(full_continues)];
all_pairwise_edges={};
idx=1;
for i=1:length(total_nodes)
	for j=1+i:length(total_nodes)
		all_pairwise_edges{idx}=[total_nodes(i),total_nodes(j)];
		idx=idx+1;
	end
end
P_cutoff=0.05;


while 1
	%compute all possibile submodels by delete one pairwise edge
	dim_full=dim3;
	ridx=1;
	temp_all_pairs={};
	temp_all_pairs_P=[];

    %store all test models
    len_edges=length(all_pairwise_edges);
    all_test_models=cell(1,len_edges);
    all_test_models_degree_freedom=zeros(1,len_edges);
    all_test_models_LL=zeros(1,len_edges);
    
    for i=1:length(all_pairwise_edges)
        %i=17 B5
		delete_edgeStr=all_pairwise_edges{i};
		new_model=mix_makeSubmodels(full_model_hom,delete_edgeStr,full_discrete,full_continues);
        %disp('make new model')
        %remove redundant submodels
        	generate_class=mix_make_model_subspace_new(full_discrete,full_discrete_sublevel,full_continues,new_model);
 	%too slow at here when have big model!! sep 2005     
 
        %disp('generate new class')
		hom_submodel=mix_make_list_submodels(generate_class);
      
		hom_len_submodel=length(hom_submodel);
		hom_out_data=out_data;

		isdebuge=0;
		hom_out_cellIndex=mix_findSubmodelCellIndex_new(cell_location, full_discrete,...
                	full_continues,hom_submodel,hom_len_submodel,full_discrete_sublevel);
		%disp('find index')
        
        	[full_out_data,LL,full_Deviance]=mix_modifiedIPS_homogeneous(all_data,all_moments,...
            		hom_out_data, cell_location, hom_len_submodel, hom_out_cellIndex,convergens,isdebuge);
		%disp('MIPS')
        %spend most of CPU!
        
	%added wang 
        dim3=mix_degree_of_freedom_new2(full_discrete,full_discrete_sublevel,full_continues,new_model);
	%disp('degree freedom')
 	%degree spend the most of time!!       


        P=Chisq(full_Deviance,dim_full-dim3);
        %disp('P')
		mix_printView(new_model, LL,full_Deviance , dim_full-dim3,P,P_cutoff,delete_edgeStr)

		if P>P_cutoff
            		%store models
           		 all_test_models{ridx}=new_model;    
            		all_test_models_LL(ridx)=LL;
            		all_test_models_degree_freedom(ridx)=dim3;
            
			%record potential delteable edges
			temp_all_pairs{ridx}=delete_edgeStr;
			temp_all_pairs_P(ridx)=P;
			ridx=ridx+1;
		end
		%pause
	end %end all test
    %disp('finishing test edges!');
	%after test all edges start to delte one edge and make new full models
	if ~isempty(temp_all_pairs_P)
		[maxP, maxPi]=max(temp_all_pairs_P);
		delete_edges=temp_all_pairs{maxPi};
		new_model=all_test_models{maxPi};
        
		hom_out_data=out_data;
		isdebuge=0;
		dim3=all_test_models_degree_freedom(maxPi);
        	LL=all_test_models_LL(maxPi);
        
       		full_Deviance=abs(2*(full_hom_model_Ls+LL/2));
		P=Chisq(full_Deviance,dim2-dim3);
		mix_printView(new_model, LL,full_Deviance , dim2-dim3,P,P_cutoff,delete_edges)
		disp(['Remove edge: ',delete_edges ]);
	
		%start to updata new full model, df, LL, all_pair_edges
		all_data.Ls=-LL/2;
		full_model_hom=new_model;
		%non-coherent, unrestricted
		%all_pairwise_edges=setdiff(all_pairwise_edges,delete_edges);
        
		%coherent, unrestricted
		all_pairwise_edges={};
		all_pairwise_edges=setdiff(temp_all_pairs,delete_edges);
        
	else
		break;
	end
end %end while
etime(clock,t0)

%diary;
